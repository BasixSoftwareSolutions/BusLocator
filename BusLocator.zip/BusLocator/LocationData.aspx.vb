﻿Imports System.Data.SqlClient
Imports System.Data
Public Class LocationData
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sSQL As String = ""
        Dim strBusNumber As String = ""
        Dim strReturn As String = ""
        Dim strDesc As String = ""

        If Request.QueryString("BusNumber") = "" Then
            Exit Sub
        End If

        strBusNumber = Request.QueryString("BusNumber")
        '********************************************************************************************************************************
        sSQL = "Select * From OPENQUERY(STORBCAD, 'SELECT * FROM ITMSAPP.vwSearchCurrentLocation WHERE BusNumber = " & strBusNumber & "')"
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()
        oComm.CommandTimeout = 100

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        Do While dr.Read()
            strDesc = "<b><font color=dimgray>Bus Driver: </b><br>" & dr("CO_Name") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Badge#: </b>" & dr("BadgeNumber") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Time: </b>" & dr("VehicleTime") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Date: </b>" & dr("VehicleDate") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Route#: </b>" & dr("ROUTE") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Block#: </b>" & dr("BLOCK") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Trip#: </b>" & dr("TripNumber") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Base: </b>" & dr("Base") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Bus#: </b>" & dr("BusNumber") & "<br>"
            'strDesc = strDesc & "<b><font color=dimgray>Speed: </b>" & dr("Speed") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Direction: </b>" & dr("Direction") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Heading: </b>" & dr("Heading") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Time Point: </b>" & dr("TimePoint") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Scheduled Time: </b>" & dr("TimePointTime") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Next Time Point: </b>" & dr("NextTimePoint") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Scheduled Time Point: </b>" & dr("NextTimePointTime") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>ETA: </b>" & dr("ETA") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Predicted ETA: </b>" & dr("NextTimePointTime") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Status: </b>" & dr("Status") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Closest Stop: </b>" & dr("CLOSEST_STOP") & "<br>"
            strDesc = strDesc & "<b><font color=dimgray>Deviation: </b>" & dr("Deviation") & "<br><br>"
        Loop

        dr.Close()
        oComm.Connection.Close()

        If strDesc = "" Then
            Dim sMsg As String = ""
            sMsg = "No Radio Data Found"
            sMsg = HttpUtility.UrlEncode(sMsg)
            Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")
        End If

        '********************************************************************************************************************************
        sSQL = "SELECT TOP 1 dbo.fConvertLonCoordinates(Longitude) AS Longitude, " +
                "dbo.fConvertLatCoordinates(Latitude) AS Latitude, GroundSpeedKnots, " +
                "GPS_Datetime, TrackAngleTrue AS Heading " +
                "FROM [dbo].[Vehicle_loc_info] " +
                "WHERE VEHICLENUMBER = " + strBusNumber + " ORDER BY GPS_DATETIME DESC"

        Dim sConn1 = System.Configuration.ConfigurationManager.ConnectionStrings("BusLocator_ConnectionString").ConnectionString
        Dim oConn1 As New SqlConnection(sConn1)
        Dim oComm1 As New SqlCommand(sSQL, oConn1)
        oComm1.CommandType = CommandType.Text

        oConn1.Open()
        oComm1.CommandTimeout = 100

        Dim dr1 As SqlDataReader

        dr1 = oComm1.ExecuteReader()

        Do While dr1.Read()
            strReturn = "{ ""BusNumber"": """ & strBusNumber & """, ""Lon"": """ & dr1("Longitude") & """, ""Lat"": """ & dr1("Latitude") & """, ""Speed"": """ & dr1("GroundSpeedKnots") & """, ""GPS_DateTime"": """ & dr1("GPS_Datetime").ToLongTimeString() & """, ""Desc"": """ & strDesc & """, ""Heading"": """ & dr1("Heading") & """}"
        Loop

        Context.Response.Write(strReturn)

        dr1.Close()
        oComm1.Connection.Close()

    End Sub

End Class