﻿
Imports System.Drawing
Imports System.IO
Public Class MyHandler
    Implements System.Web.IHttpHandler

    Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        Dim sPicPath As String

        Try
            sPicPath = context.Request.QueryString("id")

            Dim COimage As Byte()
            Dim fs As FileStream = File.OpenRead(sPicPath)
            Dim binaryReader As BinaryReader = New BinaryReader(fs)
            COimage = binaryReader.ReadBytes(fs.Length)
            fs.Close()

            Dim ms As MemoryStream = New MemoryStream(COimage)
            Dim returnImage As Image = Image.FromStream(ms)

            Dim img As System.Drawing.Image = returnImage

            Dim stream As MemoryStream = New MemoryStream()
            img.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg)
            img.Dispose()
            stream.Position = 0
            Dim data(stream.Length) As Byte
            stream.Read(data, 0, stream.Length)
            stream.Dispose()
            context.Response.Clear()
            context.Response.ContentType = "image/png"
            context.Response.BinaryWrite(data)

            context.Response.Flush()
            context.Response.End()
            context.Response.Close()

        Catch ex As Exception
            context.Response.Write(ex.Message)
            context.Response.Write("Stack Trace: " & vbCrLf & ex.StackTrace)
        End Try

    End Sub

    ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class