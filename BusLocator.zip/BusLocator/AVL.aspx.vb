﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class AVL
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Request.QueryString("sCriteria") <> "" Then
                'Get the bus location
                FindMyBus(Request.QueryString("sCriteria"))
            End If
        End If

    End Sub

    Private Sub MakeTable()

        ' Create new DataTable instance.
        ' Create a new table everytime the criteria is changed
        Dim tbl As DataTable = New DataTable("tblBusLocation")

        tbl.Columns.Add("Sequence", GetType(Integer))
        tbl.Columns.Add("Desc", GetType(String))
        tbl.Columns.Add("Lat", GetType(Double))
        tbl.Columns.Add("Lon", GetType(Double))
        tbl.Columns.Add("Time", GetType(Date))
        tbl.Columns.Add("Date", GetType(Date))
        tbl.Columns.Add("Base", GetType(String))
        tbl.Columns.Add("Badge", GetType(String))
        tbl.Columns.Add("Operator", GetType(String))
        tbl.Columns.Add("Bus", GetType(String))
        tbl.Columns.Add("Route", GetType(String))
        tbl.Columns.Add("Block", GetType(String))
        tbl.Columns.Add("Status", GetType(String))
        tbl.Columns.Add("Speed", GetType(String))
        tbl.Columns.Add("Direction", GetType(String))

        Session("tbl") = tbl
        Session("RecordCount") = 1

    End Sub

    Private Function FindCO(ByVal iBadge As Integer) As String
        On Error Resume Next

        Dim sSQL As String = ""

        'Lookup the Coach Operator
        FindCO = ""
        'Lookup badge number
        sSQL = "SELECT Operator FROM vwOperatorList WHERE Badge = " & iBadge & ""
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("C3ConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        Dim iBadgeNumber As SqlParameter = oComm.Parameters.Add("@iBadge", SqlDbType.Int)
        iBadgeNumber.Value = CInt(iBadge)

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            FindCO = Trim(dr("Operator"))
        Loop

        oConn.Close()

    End Function

    Private Function FindCOBase(ByVal iBadge As Integer) As String
        On Error Resume Next

        Dim sSQL As String = ""

        'Lookup the Coach Operator
        FindCOBase = ""
        'Lookup badge number
        sSQL = "SELECT Base FROM vwOperatorList WHERE Badge = " & iBadge & ""
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("C3ConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        Dim iBadgeNumber As SqlParameter = oComm.Parameters.Add("@iBadge", SqlDbType.Int)
        iBadgeNumber.Value = CInt(iBadge)

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            FindCOBase = Trim(dr("Base"))
        Loop

        oConn.Close()

    End Function

    Public Function FindMyBus(ByVal sCriteria As String) As Boolean
        On Error GoTo FindMyBus_Error

        'Determine if this requires a new dataset
        If Session("tbl") Is Nothing Then
            MakeTable()
        End If

        FindMyBus = False
        Dim sSQL As String = ""
        Dim sDesc As String = ""
        Dim dLat As Double
        Dim dLon As Double
        Dim sCoachOperator As String
        Dim sCoachOperatorBase As String
        Dim x As Integer
        Dim fdDate As String
        Dim dDate As DateTime
        Dim fdTime As String
        Dim dTime As DateTime
        Dim sURL As String
        Dim sCurrentBlock As String = ""
        Dim sCurrentRoute As String = ""


        sSQL = "SELECT * FROM OPENQUERY(STORBCAD, 'SELECT  VEHICLE_POSITION_LOG.VEHICLE_ID AS BusNumber, "
        sSQL = sSQL & "VEHICLE_POSITION_LOG.VEHICLE_POSITION_DATE_TIME, "
        sSQL = sSQL & "TO_CHAR(VEHICLE_POSITION_LOG.VEHICLE_POSITION_DATE_TIME,''MM/DD/YYYY'') AS VehicleDate, "
        sSQL = sSQL & "TO_CHAR(VEHICLE_POSITION_LOG.VEHICLE_POSITION_DATE_TIME,''HH24:MI:SS'') AS VehicleTime, "
        sSQL = sSQL & "VEHICLE_POSITION_LOG.LOC_X AS Lon, "
        sSQL = sSQL & "VEHICLE_POSITION_LOG.LOC_Y AS Lat, "
        sSQL = sSQL & "VEHICLE_POSITION_LOG.HEADING, "
        sSQL = sSQL & "VEHICLE_POSITION_LOG.AVERAGE_SPEED AS Speed, "
        sSQL = sSQL & "INCIDENT_LOG.CURRENT_ROUTE_ID AS Route, "
        sSQL = sSQL & "INCIDENT_LOG.BLOCK_ID AS Block, "
        sSQL = sSQL & "SUBSTR(INCIDENT_LOG.DRIVER_ID, 4, LENGTH(INCIDENT_LOG.DRIVER_ID)-3) AS BadgeNumber, "
        sSQL = sSQL & "CAD_USER.USER_ID, "
        sSQL = sSQL & "CAD_USER.FIRST_NAME, "
        sSQL = sSQL & "CAD_USER.LAST_NAME, CAD_USER.FIRST_NAME || '' '' || CAD_USER.LAST_NAME AS CO_Name, "
        sSQL = sSQL & "TRIP.TRIP_ID_EXTERNAL AS TripNumber, "
        sSQL = sSQL & "DIRECTION_CODES.DIRECTION_DESCRIPTION AS Direction, "
        sSQL = sSQL & "GARAGE.GARAGE_DESCRIPTION AS Base, "
        sSQL = sSQL & "INCIDENT_TYPES.INCIDENT_DESC AS Status "
        sSQL = sSQL & "FROM  (((((ITMSAPP.INCIDENT_LOG "
        sSQL = sSQL & "INNER JOIN (ITMSAPP.VEHICLE_POSITION_LOG "
        sSQL = sSQL & "INNER JOIN ITMSAPP.VEHICLE ON ITMSAPP.VEHICLE_POSITION_LOG.VEHICLE_ID = ITMSAPP.VEHICLE.VEHICLE_ID) ON ITMSAPP.INCIDENT_LOG.INCIDENT_LOG_ID = ITMSAPP.VEHICLE.INCIDENT_LOG_ID) "
        sSQL = sSQL & "INNER JOIN ITMSAPP.CAD_USER ON INCIDENT_LOG.DRIVER_ID = ITMSAPP.CAD_USER.USER_ID) "
        sSQL = sSQL & "INNER JOIN ITMSAPP.TRIP ON (ITMSAPP.INCIDENT_LOG.SCHED_VERSION = ITMSAPP.TRIP.SCHED_VERSION) AND (ITMSAPP.INCIDENT_LOG.TRIP_ID = ITMSAPP.TRIP.TRIP_ID)) "
        sSQL = sSQL & "INNER JOIN ITMSAPP.DIRECTION_CODES ON ITMSAPP.INCIDENT_LOG.DIRECTION_CODE_ID = ITMSAPP.DIRECTION_CODES.DIRECTION_CODE_ID) "
        sSQL = sSQL & "INNER JOIN ITMSAPP.GARAGE ON ITMSAPP.INCIDENT_LOG.GARAGE_ID = ITMSAPP.GARAGE.GARAGE_ID) "
        sSQL = sSQL & "INNER JOIN ITMSAPP.INCIDENT_TYPES ON ITMSAPP.INCIDENT_LOG.INCIDENT_TYPE = ITMSAPP.INCIDENT_TYPES.INCIDENT_TYPE "
        sSQL = sSQL & "WHERE "
        sSQL = sSQL & sCriteria & " ORDER BY INCIDENT_LOG.CURRENT_ROUTE_ID, INCIDENT_LOG.BLOCK_ID, VEHICLE.VEHICLE_POSITION_DATE_TIME')"

        'Set the connection to the AVL database      
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()
        oComm.CommandTimeout = 100

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        x = 0
        Do While dr.Read()

            'Set the time portion of the date string 
            dTime = dr("VEHICLE_POSITION_DATE_TIME")
            fdTime = dTime.ToString("HH:mm:ss")

            'Set the date portion of the date string
            dDate = dr("VEHICLE_POSITION_DATE_TIME")
            fdDate = dDate.ToString("MM/dd/yyyy")

            'This is where we set the info that will be displayed in the text bubble for each marker
            'There are two types; one for Routes and one for all others
            sDesc = "<H4>Time: " & dr("VehicleTime") & "</H4><br>"
            sDesc = sDesc & "<strong>Date: </strong>" & dr("VehicleDate") & "<br>"
            sDesc = sDesc & "<strong>Bus Driver: </strong>" & dr("CO_Name") & "<br>"
            sDesc = sDesc & "<strong>Badge#: </strong>" & dr("badgeNumber") & "<br>"
            sDesc = sDesc & "<strong>Base: </strong>" & dr("Base") & "<br>"
            sDesc = sDesc & "<strong>Route#: </strong>" & dr("ROUTE") & "<br>"
            sDesc = sDesc & "<strong>Block#: </strong>" & dr("Block") & "<br>"
            sDesc = sDesc & "<strong>Bus#: </strong>" & dr("BusNumber") & "<br>"
            sDesc = sDesc & "<strong>Speed: </strong>" & dr("SPEED") & "<br>"
            sDesc = sDesc & "<strong>Direction: </strong>" & dr("DIRECTION") & "<br>"
            sDesc = sDesc & "<strong>Status: </strong>" & dr("Status") & "<br><br>"
            sDesc = sDesc & "<a href=javascript:zoomSV(" & dr("Lat") & "," & dr("Lon") & ")><span><strong class='red'>Street View</strong></span></a><br>"
            sURL = "http://maps.google.com/maps?q=" & dr("Lat") & "+" & dr("Lon") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
            sDesc = sDesc & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"

            'Set the Lat/Lon values aside
            dLat = dr("Lat")
            dLon = dr("Lon")

            Dim objDt As New DataTable()

            objDt = Session("tbl")

            Dim objDataRow As DataRow

            ' add a row to the dataset
            objDataRow = objDt.NewRow
            If CStr(dr("ROUTE") & dr("BLOCK")) <> sCurrentRoute Then
                Session("Seq") = 1
            End If
            objDataRow("Sequence") = Session("Seq")
            objDataRow("Desc") = sDesc
            objDataRow("Lat") = dLat
            objDataRow("Lon") = dLon
            objDataRow("Time") = CStr(fdTime)
            objDataRow("Date") = CStr(fdDate)
            objDataRow("Badge") = CStr(dr("BadgeNumber"))
            objDataRow("Operator") = dr("CO_Name")
            objDataRow("Base") = dr("Base")
            objDataRow("Bus") = dr("BusNumber")
            objDataRow("Route") = dr("ROUTE")
            objDataRow("Block") = dr("BLOCK")
            sCurrentRoute = CStr(dr("ROUTE"))
            objDataRow("Status") = dr("Status")
            objDataRow("Speed") = dr("SPEED")
            objDataRow("Direction") = dr("DIRECTION")
            objDt.Rows.Add(objDataRow)

            Session("tbl") = objDt
            Session("Seq") = Session("Seq") + 1
            x = x + 1
            Session("RecordCount") = x
        Loop

        dr.Close()
        oComm.Connection.Close()

        'If no records exist, redirect and display message
        If x = 0 Then
            oConn.Close()
            oConn.Dispose()
            Response.Redirect("MessageDisplay.aspx?Msg=No Records Exist for this Criteria")
            Exit Function
        End If

        'Load Javascript
        LoadJavaScript(dLat, dLon)

FindMyBus_Exit:
        oConn.Close()
        oConn.Dispose()
        Exit Function

FindMyBus_Error:
        Dim sMsg As String = ""

        sMsg = "Error Number: " & Err.Number & vbCrLf & "Description: " & Err.Description & ""
        sMsg = HttpUtility.UrlEncode(sMsg)
        Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")

        FindMyBus = False

        Resume FindMyBus_Exit

    End Function

    Private Sub LoadJavaScript(ByVal dLat As Double, ByVal dLon As Double)
        On Error GoTo LoadJavaScript_Error

        Dim objDt As New DataTable()
        Dim sJScript As String = ""
        Dim i As Integer
        Dim sDesc As String = ""
        Dim iSeq As Integer
        Dim sName As String = ""
        Dim sTime As String = ""
        Dim sRoute As String = ""
        Dim bValidShapeFile As Boolean = False
        Dim sStr As String = ""
        Dim sMapType As String = ""
        Dim sIcon As String = ""
        Dim sColor As String = "#00FFFF"
        Dim dStartDate As Date
        Dim dEndDate As Date
        Dim dStartTime As Date
        Dim dEndTime As Date
        Dim iID As Integer
        Dim dRunDate As Date

        'This is all of the javascript code that is created each time the page is loaded
        'using the ClientScript.RegisterClientScriptBlock method
        sJScript = "<script type=""text/javascript"" src=""mapIconMaker.js""></script>" & vbCrLf
        'sJScript = "<script type=""text/javascript"" src=""http://maps.google.com/maps/api/js?sensor=false&amp;v=3&amp;libraries=geometry""></script>" & vbCrLf

        sJScript = sJScript & "<script type=""text/javascript"" src=""StyledMarker.js""></script>" & vbCrLf

        sJScript = sJScript & "<script type=""text/javascript"">" & vbCrLf

        'Set the Div size that contains the map
        sJScript = sJScript & "setFrameSize()" & vbCrLf
        sJScript = sJScript & "document.all.side_bar.style.visibility = 'visible'; " & vbCrLf

        'this variable will collect the html which will eventually be placed in the side_bar
        sJScript = sJScript & "var side_bar_html = ""<strong>View Details</strong><hr>"";" & vbCrLf

        '***Create the Map*******************************************************************************
        sJScript = sJScript & "var mapOptions = {" & vbCrLf
        sJScript = sJScript & "zoom: 14," & vbCrLf
        sJScript = sJScript & "panControl: true, " & vbCrLf
        sJScript = sJScript & "zoomControl: true, " & vbCrLf
        sJScript = sJScript & "mapTypeControl: true, " & vbCrLf
        sJScript = sJScript & "scaleControl: true, " & vbCrLf
        sJScript = sJScript & "streetViewControl: true, " & vbCrLf
        sJScript = sJScript & "overviewMapControl: true, " & vbCrLf
        sJScript = sJScript & "center: new google.maps.LatLng(" & dLat & ", " & dLon & "), " & vbCrLf
        sJScript = sJScript & "mapTypeId: google.maps.MapTypeId.ROADMAP}" & vbCrLf
        sJScript = sJScript & "var map = new google.maps.Map(document.getElementById(""map""), mapOptions);" & vbCrLf
        '***End Create the Map*****************************************************************************

        sJScript = sJScript & "var gmarkers = [];" & vbCrLf

        '***function to create the marker and set up the event window*********************************
        sJScript = sJScript & "function createMarker(seq,point,name,html,time,color,id) {" & vbCrLf
        'Create the icons
        sJScript = sJScript & "var styleIcon = new StyledIcon(StyledIconTypes.BUBBLE,{color:color,text:name});" & vbCrLf
        sJScript = sJScript & "var busMarker = new StyledMarker({styleIcon:styleIcon,position:point,map:map,id:id});" & vbCrLf
        sJScript = sJScript & "var infowindow = new google.maps.InfoWindow({content: html});" & vbCrLf
        sJScript = sJScript & "google.maps.event.addListener(busMarker, ""click"", function() {" & vbCrLf
        sJScript = sJScript & "infowindow.open(map,busMarker);" & vbCrLf
        sJScript = sJScript & "});" & vbCrLf

        'save the info we need to use later for the side_bar
        sJScript = sJScript & "gmarkers.push(busMarker);" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        '***End function to create the marker and set up the event window*********************************

        'This function picks up the click and opens the corresponding info window
        sJScript = sJScript & "function myclick(i) {" & vbCrLf
        sJScript = sJScript & "google.maps.event.trigger(gmarkers[i], ""click"");" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "var bounds = new google.maps.LatLngBounds();" & vbCrLf

        'Create the Array
        sJScript = sJScript & "markerArray = new Array(" & Session("RecordCount") & "); " & vbCrLf
        sJScript = sJScript & "for (i = 0; i < markerArray.length; ++ i)" & vbCrLf
        sJScript = sJScript & "markerArray [i] = new Array(" & Session("RecordCount") & ");" & vbCrLf

        'Add the points   
        objDt = Session("tbl")
        sRoute = objDt.Rows(0).Item("Route")
        For i = 0 To objDt.Rows.Count - 1
            iSeq = CInt(objDt.Rows(i).Item("Sequence"))
            sDesc = CStr(objDt.Rows(i).Item("Desc"))
            dLat = CDbl(objDt.Rows(i).Item("Lat"))
            dLon = CDbl(objDt.Rows(i).Item("Lon"))
            sName = objDt.Rows(i).Item("Block") & "." & Left(objDt.Rows(i).Item("Direction"), 1)
            iID = CInt(objDt.Rows(i).Item("Block"))
            sTime = objDt.Rows(i).Item("Time")
            If sRoute <> objDt.Rows(i).Item("Route") Then
                sColor = "#33CCCC"
            Else
                sColor = "#FFA953"
            End If

            sJScript = sJScript & "markerArray[" & i & "][0]=" & iSeq & ";" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][1]=""" & sDesc & """;" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][2]=" & dLat & ";" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][3]=" & dLon & ";" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][4]=""" & sName & """;" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][5]=""" & sTime & """;" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][6]=""" & sColor & """;" & vbCrLf
            sJScript = sJScript & "markerArray[" & i & "][7]=""" & iID & """;" & vbCrLf
        Next

        dStartDate = CDate(Request.QueryString("Start") & ":00").ToString("MM-dd-yyyy HH:mm:ss")
        sJScript = sJScript & "var getStartTime = new Date('" & dStartDate & "'); " & vbCrLf
        sJScript = sJScript & "var getEndTime = new Date('" & DateAdd(DateInterval.Minute, 2, dStartDate) & "'); " & vbCrLf

        sJScript = sJScript & "var startTime = getStartTime.getHours() + ':' + pad(getStartTime.getMinutes()) + ':00';" & vbCrLf
        sJScript = sJScript & "var endTime = getEndTime.getHours() + ':' + pad(getEndTime.getMinutes()) + ':00';" & vbCrLf

        sJScript = sJScript & "var gmarkers = [];" & vbCrLf
        sJScript = sJScript & "for (k = 0; k < markerArray.length; ++ k) {" & vbCrLf

        sJScript = sJScript & "var getTime = new Date(markerArray[k][5]);" & vbCrLf
        sJScript = sJScript & "var time = getTime.getHours() + ':' + pad(getTime.getMinutes()) + ':' + pad(getTime.getSeconds());" & vbCrLf

        sJScript = sJScript & "if (time >= startTime && time <= endTime) {" & vbCrLf
        sJScript = sJScript & "var point = new google.maps.LatLng(markerArray[k][2], markerArray[k][3]);" & vbCrLf
        sJScript = sJScript & "var marker = createMarker(markerArray[k][0], point, markerArray[k][4], markerArray[k][1], markerArray[k][5], markerArray[k][6], markerArray[k][7])" & vbCrLf
        sJScript = sJScript & "bounds.extend(point);" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        sJScript = sJScript & "map.fitBounds(bounds);" & vbCrLf

        '***Find the Intersection***************************************************************************
        If Request.QueryString("Inter") <> "" Then
            sJScript = sJScript & "var geocoder = new google.maps.Geocoder();" & vbCrLf
            sJScript = sJScript & "var address = '" & Request.QueryString("Inter") & "'" & vbCrLf
            sJScript = sJScript & "geocoder.geocode({'address': address}, function(results, status) { " & vbCrLf
            sJScript = sJScript & "if (status == google.maps.GeocoderStatus.OK) { " & vbCrLf
            sJScript = sJScript & "map.setCenter(results[0].geometry.location); " & vbCrLf
            sJScript = sJScript & "var styleIcon = new StyledIcon(StyledIconTypes.MARKER,{color:'#FF00FF',text:'X'});" & vbCrLf
            sJScript = sJScript & "var marker = new StyledMarker({styleIcon:styleIcon, " & vbCrLf
            sJScript = sJScript & "map: map, " & vbCrLf
            sJScript = sJScript & "position: results[0].geometry.location " & vbCrLf
            sJScript = sJScript & "}); " & vbCrLf
            sJScript = sJScript & "} else { " & vbCrLf
            sJScript = sJScript & "alert(""Could not find intersection: "" + status);" & vbCrLf
            sJScript = sJScript & "} " & vbCrLf
            sJScript = sJScript & "}); " & vbCrLf
        End If
        '***End Find the Intersection****************************************************************************

        '***Function to breakout the Street View window**********************************************************
        sJScript = sJScript & "function zoomSV(vLat, vLong) " & vbCrLf
        sJScript = sJScript & "{" & vbCrLf
        sJScript = sJScript & "varStr = 'Lat=' + vLat + '&Long=' + vLong" & vbCrLf
        sJScript = sJScript & "varURL = 'ZoomSV.aspx?' + varStr;" & vbCrLf
        sJScript = sJScript & "objWin = window.open(varURL, '', 'left=10,top=10,toolbar=false,status=false,directories=false,menubar=false,scrollbars=no,resizable=yes,copyhistory=false,width=825,height=525');" & vbCrLf
        sJScript = sJScript & "}  " & vbCrLf
        '***End Function to breakout the Street View window*************************************************************************

        sJScript = sJScript & "function startPlay() {" & vbCrLf
        sJScript = sJScript & "var play = self.setInterval(""turnMeOn()"", " & (Request.QueryString("Speed") * 1000) & ");" & vbCrLf
        sJScript = sJScript & "i=1;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        '***Start function turnMeOff*************************************************************************
        sJScript = sJScript & "function turnMeOff(markerID) {" & vbCrLf
        sJScript = sJScript & "for (x in gmarkers) { " & vbCrLf
        sJScript = sJScript & "if (gmarkers[x].id == markerID) {" & vbCrLf
        sJScript = sJScript & "gmarkers[x].setMap(null);" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        '***End function turnMeOff*************************************************************************

        '***Start function turnMeOn()*************************************************************************
        sJScript = sJScript & "function turnMeOn() {" & vbCrLf
        sJScript = sJScript & "if (document.getElementById(""cmdPause"").value == ""Play >>"") {" & vbCrLf
        sJScript = sJScript & "return true;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        dStartTime = CDate(Request.QueryString("Start") & ":00").ToString("MM-dd-yyyy HH:mm:ss")
        dEndTime = CDate(Request.QueryString("End") & ":00").ToString("MM-dd-yyyy HH:mm:ss")

        sJScript = sJScript & "var stopTime = new Date('" & dEndTime & "');" & vbCrLf
        sJScript = sJScript & "var playStartTime = new Date('" & dStartTime & "');" & vbCrLf
        sJScript = sJScript & "var playEndTime = new Date('" & dStartTime & "');" & vbCrLf
        sJScript = sJScript & "var newStartTime = new Date(playStartTime.setMinutes(playStartTime.getMinutes() + (i*1))); " & vbCrLf
        sJScript = sJScript & "var newEndTime = new Date(playEndTime.setMinutes(playEndTime.getMinutes() + (i*1 + 1))); " & vbCrLf

        sJScript = sJScript & "if (newStartTime >= stopTime) {" & vbCrLf
        sJScript = sJScript & "return true;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        dRunDate = CDate(Request.QueryString("Start") & ":00").ToString("MM-dd-yyyy")

        sJScript = sJScript & "for (k = 0; k < markerArray.length; ++ k) {" & vbCrLf
        sJScript = sJScript & "var tTime = new Date(markerArray[k][5]);" & vbCrLf
        sJScript = sJScript & "var time = new Date('" & dRunDate & "' + ' ' + tTime.getHours() + ':' + pad(tTime.getMinutes()) + ':' + pad(tTime.getSeconds()));" & vbCrLf
        sJScript = sJScript & "if (time > newStartTime && time < newEndTime) {" & vbCrLf
        sJScript = sJScript & "turnMeOff(markerArray[k][7]);" & vbCrLf
        sJScript = sJScript & "var point = new google.maps.LatLng(markerArray[k][2], markerArray[k][3]);" & vbCrLf
        sJScript = sJScript & "var marker = createMarker(markerArray[k][0], point, markerArray[k][4], markerArray[k][1], markerArray[k][5], markerArray[k][6], markerArray[k][7])" & vbCrLf
        sJScript = sJScript & "bounds.extend(point);" & vbCrLf
        sJScript = sJScript & "} " & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "i++;" & vbCrLf
        sJScript = sJScript & "side_bar_html = newStartTime.getHours() + ':' + pad(newStartTime.getMinutes()) + ' - ' + newEndTime.getHours() + ':' + pad(newEndTime.getMinutes()) ;" & vbCrLf
        sJScript = sJScript & "document.getElementById(""side_bar"").innerHTML = side_bar_html;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        '***End function turnMeOn()*************************************************************************

        sJScript = sJScript & "function pad(number) {" & vbCrLf
        sJScript = sJScript & "var str = '' + number;" & vbCrLf
        sJScript = sJScript & "while (str.length < 2) {" & vbCrLf
        sJScript = sJScript & "str = '0' + str;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "return str;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

EndScript:
        sJScript = sJScript & "</scr" & "ipt>"
        ClientScript.RegisterClientScriptBlock(GetType(AVL), "NewWin", sJScript)

LoadJavaScript_Exit:
        Exit Sub

LoadJavaScript_Error:
        Dim sMsg As String = ""

        sMsg = "Error Number: " & Err.Number & vbCrLf & "Description: " & Err.Description & ""

        sMsg = HttpUtility.UrlEncode(sMsg)
        Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")

        Resume LoadJavaScript_Exit

    End Sub

    Public Function GetStatus(ByVal sStatus As String) As String
        On Error Resume Next

        'Convert the status code to status from the AVL dataset
        Select Case sStatus
            Case "N"
                GetStatus = "Normal"
            Case "E"
                GetStatus = "Emergency"
            Case "U"
                GetStatus = "Unknown Location"
            Case "A"
                GetStatus = "Ahead of schedule"
            Case "B"
                GetStatus = "Behind Schedule"
            Case "O"
                GetStatus = "Off-Route"
            Case "M"
                GetStatus = "Mechanical Failure Discrete"
            Case "D"
                GetStatus = "Detoured"
            Case "R"
                GetStatus = "RSA Suspended"
            Case Else
                GetStatus = "N/A"
        End Select

    End Function

    Private Function GetShapePatternID() As Integer
        On Error Resume Next

       Dim sStr As String = ""
        Dim sSQL As String = ""
        Dim objDt As New DataTable()

        GetShapePatternID = 0
        objDt = Session("tbl")

        sSQL = "SELECT shape_id FROM dbo.tblTrips WHERE trip_id = " & CInt(objDt.Rows(0).Item("Trip")) & ""

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            GetShapePatternID = dr("shape_id")
        Loop

    End Function

    Private Function GetShapeFile() As String
        On Error Resume Next

        Dim sStr As String = ""
        Dim sSQL As String = ""
        Dim iShapeFileID As Integer

        GetShapeFile = ""

        iShapeFileID = GetShapePatternID()

        If iShapeFileID = 0 Then Exit Function

        sSQL = "SELECT shape_pt_sequence, shape_pt_lat, shape_pt_lon FROM tblShapeFile WHERE shape_id = " & iShapeFileID & " ORDER BY shape_pt_sequence"
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            sStr = sStr & "new GLatLng(" & dr("shape_pt_lat") & "," & dr("shape_pt_lon") & "), " & vbCrLf
        Loop

        sStr = Left(sStr, Len(sStr) - 2)
        GetShapeFile = sStr

    End Function
End Class
