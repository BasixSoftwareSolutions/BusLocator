﻿Imports System.Data.SqlClient
Imports System.Data
Imports Oracle.DataAccess.Client

Public Class Locator
    Inherits System.Web.UI.Page

    Private Sub LoadBadge(ByVal oControl As DropDownList)
        oControl.DataSourceID = "SqlDataSource1"
        oControl.DataTextField = "Operator"
        oControl.DataValueField = "User_ID"
        oControl.DataBind()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Private Sub LoadBlock(ByRef oControl As DropDownList)
        Dim sSQL As String
        sSQL = "SELECT ORBCADAPP.BLOCK.BLOCK_ID AS Bus_Run FROM ORBCADAPP.BLOCK WHERE NONSCHEDULE = 0 ORDER BY BLOCK_ID"

        'Set the connection to the AVL database      
        Dim sPassword As String = """devappPWDrpt"""
        Dim oConn As OracleConnection = New OracleConnection()
        oConn.ConnectionString = "Data Source=STORBCAD;User Id=""DEVAPP_RPT"";Password=" & sPassword & ";"
        Dim oComm As OracleCommand = New OracleCommand(sSQL, oConn)
        oConn.Open()

        Dim oReader As OracleDataReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Bus_Run"
        oControl.DataValueField = "Bus_Run"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()
        oConn.Dispose()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Private Sub LoadBus(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        sSQL = "SELECT BusNumber AS Bus FROM qselBATS"

        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Bus"
        oControl.DataValueField = "Bus"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sSQL As String = ""

        If Not IsPostBack Then
            Session.Contents.RemoveAll()
            LoadBadge(Me.cboAVLBadge)
            Me.hfPage.Value = "BusLocationDetails.aspx"
            Me.SpiceIframe1.SourceURL = "~/MyBus.aspx"
            If Request.QueryString("SQLString") <> Nothing Then
                Me.txtAVLDate.Text = Request.QueryString("Date")
                Me.txtAVLStartTime.Text = Request.QueryString("StartTime")
                Me.txtAVLEndTime.Text = Request.QueryString("EndTime")
                Me.cboAVLBadge.SelectedIndex = cboAVLBadge.Items.IndexOf(cboAVLBadge.Items.FindByText(Request.QueryString("Badge")))
                Me.cboAVLBlock.Text = Request.QueryString("Block")
                Me.cboAVLBus.Text = Request.QueryString("BusNum")
                sSQL = HttpUtility.UrlEncode(Request.QueryString("SQLString"))
                Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=AVL"
            End If
        End If

        Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "hideCalendar", "function hideCalendar(cb) { cb.hide(); }", True)

    End Sub

    Protected Sub cmdAVLGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAVLGo.Click
        Dim sCriteria As String = ""
        Dim sSQL As String = ""
        Dim sDate As String = ""
        Dim sBlock As String = ""
        Dim sRoute As String = ""
        Dim dStartTime As DateTime
        Dim dEndTime As DateTime

        Session.Clear()
        Me.hfPage.Value = "BusLocationDetails.aspx"

        If Me.txtAVLDate.Text <> "" Then
            sDate = CDate(Me.txtAVLDate.Text).ToString("dd-MMM-yyyy")
        Else
            lblErrorMsg.Text = "You must select a date."
            Exit Sub
        End If

        If Me.cboAVLBus.Text <> "" Then
            sCriteria = sCriteria & "(BusNumber = '" & CStr(Me.cboAVLBus.Text) & "') AND "
        End If

        If Me.cboAVLBlock.Text <> "" Then
            sCriteria = sCriteria & "(Block = " & Me.cboAVLBlock.Text & ") AND "
        End If

        If Me.cboAVLBadge.Text <> "" Then
            sCriteria = sCriteria & "(BadgeNumber = '" & Me.cboAVLBadge.Text & "') AND "
        End If

        If Me.txtAVLStartTime.Text <> "" And Me.txtAVLEndTime.Text <> "" Then
            dStartTime = CDate(Me.txtAVLStartTime.Text).ToLongTimeString
            dEndTime = CDate(Me.txtAVLEndTime.Text).ToLongTimeString
            sCriteria = sCriteria & "(VEHICLE_POSITION_DATE_TIME Between TO_DATE('" & CDate(sDate & " " & dStartTime).ToString("dd-MMM-yyyy HH:mm:ss") & "', 'dd-mon-yyyy hh24:mi:ss') AND TO_DATE('" & CDate(sDate & " " & dEndTime).ToString("dd-MMM-yyyy HH:mm:ss") & "', 'dd-mon-yyyy hh24:mi:ss')) AND "
        Else
            lblErrorMsg.Text = "You must select an incident time."
            Exit Sub
        End If

        If sCriteria = "" Then
            lblErrorMsg.Text = "You must select some criteria."
            Exit Sub
        Else
            sCriteria = Left(sCriteria, Len(sCriteria) - 5)            
            sSQL = "SELECT * FROM ORBCADAPP.vwSearchHistoricalLocation WHERE " & sCriteria & " ORDER BY VEHICLE_POSITION_DATE_TIME"
        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=AVL"

    End Sub

    Protected Sub lbClearAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lbClearAll.Click

        Me.txtAVLDate.Text = ""
        Me.txtAVLEndTime.Text = ""
        Me.txtAVLStartTime.Text = ""
        Me.cboAVLBadge.SelectedIndex = -1
        Me.cboAVLBlock.Text = ""
        Me.cboAVLBus.Text = ""
        Session.RemoveAll()

        Me.SpiceIframe1.SourceURL = "~/MyBus.aspx"

    End Sub
End Class

