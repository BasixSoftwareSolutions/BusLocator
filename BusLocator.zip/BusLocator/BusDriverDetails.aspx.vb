﻿Public Class BusDriverDetails
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        Dim objDt As New DataTable()
        objDt = Session("tbl")

        gvBusDetails.DataSource = objDt
        gvBusDetails.DataBind()

    End Sub

End Class