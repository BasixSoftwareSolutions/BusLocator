﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class MyAVL
    Inherits System.Web.UI.Page


    Private Sub LoadBlock(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        sSQL = "SELECT BlockNumber AS Bus_Run FROM qselBusRuns ORDER BY BlockNumber"

        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Bus_Run"
        oControl.DataValueField = "Bus_Run"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Private Sub LoadRoute(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        sSQL = "SELECT [List of Lines].Line AS Route FROM [List of Lines] GROUP BY [List of Lines].Line ORDER BY [List of Lines].Line"

        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Route"
        oControl.DataValueField = "Route"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            LoadRoute(Me.cboRoute1)
            LoadRoute(Me.cboRoute2)
            Me.SpiceIframe1.SourceURL = "~/AVL.aspx"
            Me.txtSpeedControl.Text = "1.5"
        End If

        Me.Page.ClientScript.RegisterClientScriptBlock(Me.GetType(), "hideCalendar", "function hideCalendar(cb) { cb.hide(); }", True)

    End Sub

    Protected Sub cmdAVLGo_Click1(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAVLGo.Click
        Dim sCriteria As String = ""
        Dim sSQL As String = ""
        Dim sDate As String = ""
        Dim sBlock As String = ""
        Dim sRoute As String = ""
        Dim dStartTime As DateTime
        Dim dEndTime As DateTime

        Session.Clear()

        If Me.txtAVLDate.Text <> "" Then
            sDate = CDate(Me.txtAVLDate.Text).ToString("dd-MMM-yyyy")
        Else
            lblErrorMsg.Text = "You must select a date."
            Exit Sub
        End If

        If Me.cboRoute1.Text <> "" And Me.cboRoute2.Text <> "" Then
            sCriteria = sCriteria & "((INCIDENT_LOG.CURRENT_ROUTE_ID = " & Me.cboRoute1.Text & ") OR "

        ElseIf Me.cboRoute1.Text <> "" And Me.cboRoute2.Text = "" Then
            sCriteria = sCriteria & "(INCIDENT_LOG.CURRENT_ROUTE_ID = " & Me.cboRoute1.Text & ") AND "
        Else
            lblErrorMsg.Text = "You must select a Route."
            Exit Sub
        End If

        If Me.cboRoute2.Text <> "" Then
            sCriteria = sCriteria & "(INCIDENT_LOG.CURRENT_ROUTE_ID = " & Me.cboRoute2.Text & ")) AND "
        End If

        If Me.txtAVLStartTime.Text <> "" And Me.txtAVLEndTime.Text <> "" Then
            dStartTime = CDate(Me.txtAVLStartTime.Text).ToLongTimeString
            dEndTime = CDate(Me.txtAVLEndTime.Text).ToLongTimeString
            sCriteria = sCriteria & "(VEHICLE_POSITION_LOG.VEHICLE_POSITION_DATE_TIME Between TO_DATE('" & CDate(sDate & " " & dStartTime).ToString("dd-MMM-yyyy HH:mm:ss") & "', 'dd-mon-yyyy hh24:mi:ss') AND TO_DATE('" & CDate(sDate & " " & dEndTime).ToString("dd-MMM-yyyy HH:mm:ss") & "', 'dd-mon-yyyy hh24:mi:ss')) "
        Else
            lblErrorMsg.Text = "You must select an incident time."
            Exit Sub
        End If

        If sCriteria = "" Then
            lblErrorMsg.Text = "You must select some criteria."
            Exit Sub
        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "AVL.aspx?sCriteria=" & sCriteria & "&Inter=" & Me.txtIntersection.Text & "&Start=" & Me.txtAVLDate.Text & " " & Me.txtAVLStartTime.Text & "&End=" & Me.txtAVLDate.Text & " " & Me.txtAVLEndTime.Text & "&Speed=" & Me.txtSpeed.Text

    End Sub

End Class