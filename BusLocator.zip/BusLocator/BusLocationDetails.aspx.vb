﻿Imports System.Data
Imports System.Data.SqlClient

Public Class BusLocationDetails
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sSQL As String = ""
        Dim sPicPath As String = ""
        Dim sCOName As String = ""
        Dim strDriverID As String = ""
        Dim sCompany As String = ""

        Try
            strDriverID = Request.QueryString("DriverID")

            If strDriverID = "" Then

            Else
                If Left(strDriverID, 2) = "60" Then
                    strDriverID = CStr(CInt(Right(strDriverID, 5))).PadLeft(9, "0")
                Else
                    strDriverID = CStr(CInt(strDriverID)).PadLeft(9, "0")
                End If

            End If

            sSQL = "SELECT dbo.OCTA_EmployeeMaster.FirstName + ' ' + dbo.OCTA_EmployeeMaster.LastName AS COName, dbo.OCTA_EmployeeMaster.Company, dbo.OCTA_EmployeeMaster.BadgeNumber, dbo.OCTA_EmployeeDetail.PictureFileLocation "
            sSQL = sSQL & "FROM dbo.OCTA_EmployeeDetail LEFT OUTER Join dbo.OCTA_EmployeeMaster ON dbo.OCTA_EmployeeDetail.EmployeeID = dbo.OCTA_EmployeeMaster.EmpID "
            sSQL = sSQL & "WHERE dbo.OCTA_EmployeeMaster.EmpID = '" & strDriverID & "'"

            Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("AppStoreConnStr").ConnectionString
            Dim oConn As New SqlConnection(sConn)
            Dim oComm As New SqlCommand(sSQL, oConn)
            oComm.CommandType = CommandType.Text

            oConn.Open()
            oComm.CommandTimeout = 100

            Dim dr As SqlDataReader

            dr = oComm.ExecuteReader()

            Do While dr.Read()
                sPicPath = dr("PictureFileLocation")
                sCompany = dr("Company")
                sCOName = dr("COName")
            Loop

            dr.Close()
            oComm = Nothing
            oConn.Close()

            lblCOName.Text = sCOName
            lblCompany.Text = sCompany

            If sPicPath = "" Then
                imgDriverPic.ImageUrl = "\images\MyPicture.jpg"
            Else
                imgDriverPic.ImageUrl = String.Format("MyHandler.ashx?id={0}", sPicPath)
            End If


        Catch ex As Exception
            Console.WriteLine(ex.Message)
            imgDriverPic.ImageUrl = "\images\MyPicture.jpg"
        End Try

    End Sub


End Class
