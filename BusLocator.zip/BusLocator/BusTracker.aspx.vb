﻿Imports System.Data.SqlClient
Public Class BusTracker
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Request.QueryString("BusNumber") <> "" Then
                txtBusNumber.Value = Request.QueryString("BusNumber")
            End If
            Call GPSPageHitCount()
        End If

    End Sub

    Protected Sub GPSPageHitCount()

        Dim iCount As Integer
        Dim sSQL As String = ""
        sSQL = "SELECT Value FROM dbo.tblSystem WHERE Name = 'GPSPageHit'"

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            iCount = dr("Value")
        Loop

        oConn.Close()
        oComm = Nothing

        sSQL = ""
        sSQL = "UPDATE dbo.tblSystem SET Value = " & iCount + 1 & " WHERE Name = 'GPSPageHit'"

        oConn = New SqlConnection(sConn)
        oComm = New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        dr = oComm.ExecuteReader()

        dr.Close()
        oConn.Close()
        oComm = Nothing

    End Sub
End Class