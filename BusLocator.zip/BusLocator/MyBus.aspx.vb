﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class MyBus
    Inherits System.Web.UI.Page
    Dim sSQL As String
    Dim sConn As String

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not IsPostBack Then
            If Request.QueryString("sSQL") <> "" Then
                If Request.QueryString("Mode") = "GFI" Then
                    FindMyBusGFI(Request.QueryString("sSQL"))
                Else
                    FindMyBus(Request.QueryString("sSQL"))
                    Server.ScriptTimeout = 60
                End If
            End If
        End If

    End Sub

    Private Sub MakeTable()

        ' Create new DataTable instance.
        ' Create a new table everytime the criteria is changed
        Dim tbl As DataTable = New DataTable("tblBusLocation")

        tbl.Columns.Add("Sequence", GetType(Integer))
        tbl.Columns.Add("Desc", GetType(String))
        tbl.Columns.Add("Lat", GetType(Double))
        tbl.Columns.Add("Lon", GetType(Double))
        tbl.Columns.Add("Time", GetType(String))
        tbl.Columns.Add("Date", GetType(Date))
        tbl.Columns.Add("Base", GetType(String))
        tbl.Columns.Add("Badge", GetType(String))
        tbl.Columns.Add("Operator", GetType(String))
        tbl.Columns.Add("Bus", GetType(String))
        tbl.Columns.Add("Route", GetType(String))
        tbl.Columns.Add("Block", GetType(String))
        tbl.Columns.Add("Status", GetType(String))
        tbl.Columns.Add("Speed", GetType(String))
        tbl.Columns.Add("Direction", GetType(String))
        tbl.Columns.Add("Heading", GetType(String))
        tbl.Columns.Add("Trip", GetType(String))
        tbl.Columns.Add("TimePoint", GetType(String))
        tbl.Columns.Add("TimePointTime", GetType(String))
        tbl.Columns.Add("NextTimePoint", GetType(String))
        tbl.Columns.Add("NextTimePointTime", GetType(String))
        tbl.Columns.Add("Deviation", GetType(String))
        tbl.Columns.Add("ClosestStop", GetType(String))

        Session("tbl") = tbl
        Session("Count") = 1

    End Sub

    Public Function FindMyBus(ByVal sSQL As String) As Boolean
        On Error GoTo FindMyBus_Error

        'Clear all session variables
        'If Session("NewFetch") = True Then
        'Session.Contents.RemoveAll()
        'End If

        'Determine if this requires a new dataset
        If Session("tbl") Is Nothing Then
            MakeTable()
        End If

        FindMyBus = False
        Dim sDesc As String = ""
        Dim dLat As Double
        Dim dLon As Double
        Dim sCoachOperator As String
        Dim sCoachOperatorBase As String
        Dim x As Integer
        Dim fdDate As String
        Dim dDate As DateTime
        Dim fdTime As String
        Dim dTime As DateTime
        Dim sURL As String

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()
        oComm.CommandTimeout = 100

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        x = 0
        Do While dr.Read()

            'This is where we set the info that will be displayed in the text bubble for each marker
            'There are two types; one for Routes and one for all others
            If Request.QueryString("Mode") = "Search" Then
                sDesc = "<H4>Bus Driver: </strong>" & dr("CO_Name") & " - #" & dr("BadgeNumber") & "</H4>"
                sDesc = sDesc & "<strong>Time: </strong>" & dr("VehicleTime") & "<br>"
                sDesc = sDesc & "<strong>Date: </strong>" & dr("VehicleDate") & "<br>"
                sDesc = sDesc & "<strong>Route#: </strong>" & dr("ROUTE") & "<br>"
                sDesc = sDesc & "<strong>Block#: </strong>" & dr("BLOCK") & "<br>"
                sDesc = sDesc & "<strong>Trip#: </strong>" & dr("TripNumber") & "<br>"
                sDesc = sDesc & "<strong>Base: </strong>" & dr("Base") & "<br>"
                sDesc = sDesc & "<strong>Bus#: </strong>" & dr("BusNumber") & "<br>"
                sDesc = sDesc & "<strong>Speed: </strong>" & dr("Speed") & "<br>"
                sDesc = sDesc & "<strong>Direction: </strong>" & dr("Direction") & "<br>"
                sDesc = sDesc & "<strong>Heading: </strong>" & dr("Heading") & "<br>"
                sDesc = sDesc & "<strong>Time Point: </strong>" & dr("TimePoint") & "<br>"
                sDesc = sDesc & "<strong>Scheduled Time: </strong>" & dr("TimePointTime") & "<br>"
                sDesc = sDesc & "<strong>Next Time Point: </strong>" & dr("NextTimePoint") & "<br>"
                sDesc = sDesc & "<strong>Scheduled Time Point: </strong>" & dr("NextTimePointTime") & "<br>"
                sDesc = sDesc & "<strong>ETA: </strong>" & dr("ETA") & "<br>"
                sDesc = sDesc & "<strong>Predicted ETA: </strong>" & dr("NextTimePointTime") & "<br>"
                sDesc = sDesc & "<strong>Status: </strong>" & dr("Status") & "<br>"
                sDesc = sDesc & "<strong>Closest Stop: </strong>" & dr("CLOSEST_STOP") & "<br>"
                sDesc = sDesc & "<strong>Deviation: </strong>" & dr("Deviation") & "<br><br>"
                '*********************************************
                'sDesc = sDesc & "<a href=javascript:GetCOPicture(" & Trim(dr("BadgeNumber")) & ")><span><strong class='red'>Driver Picture</strong></span></a><br>"
                '********************************************
                sDesc = sDesc & "<a href=javascript:zoomSV(" & dr("Lat") & "," & dr("Lon") & ")><span><strong class='red'>Street View</strong></span></a><br>"
                sURL = "http://maps.google.com/maps?q=" & dr("Lat") & "+" & dr("Lon") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
                sDesc = sDesc & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"
            ElseIf Request.QueryString("Mode") = "Route" Then
                sDesc = "<H4>Bus Driver: </strong>" & Trim(dr("CO_Name")) & " - #" & Trim(dr("BadgeNumber")) & "</H4>"
                sDesc = sDesc & "<strong>Time: </strong>" & Trim(dr("VehicleTime")) & "<br>"
                sDesc = sDesc & "<strong>Date: </strong>" & Trim(dr("VehicleDate")) & "<br>"
                sDesc = sDesc & "<strong>Route#: </strong>" & Trim(dr("ROUTE")) & "<br>"
                sDesc = sDesc & "<strong>Block#: </strong>" & Trim(dr("BLOCK")) & "<br>"
                sDesc = sDesc & "<strong>Trip#: </strong>" & Trim(dr("TripNumber")) & "<br>"
                sDesc = sDesc & "<strong>Base: </strong>" & Trim(dr("Base")) & "<br>"
                sDesc = sDesc & "<strong>Bus#: </strong>" & Trim(dr("BusNumber")) & "<br>"
                sDesc = sDesc & "<strong>Speed: </strong>" & Trim(dr("Speed")) & "<br>"
                sDesc = sDesc & "<strong>Direction: </strong>" & Trim(dr("Direction")) & "<br>"
                sDesc = sDesc & "<strong>Heading: </strong>" & Trim(dr("Heading")) & "<br>"
                sDesc = sDesc & "<strong>Time Point: </strong>" & Trim(dr("TimePoint")) & "<br>"
                sDesc = sDesc & "<strong>Next Time Point: </strong>" & Trim(dr("NextTimePoint")) & "<br>"
                sDesc = sDesc & "<strong>Status: </strong>" & Trim(dr("Status")) & "<br><br>"
                '*********************************************
                'sDesc = sDesc & "<a href=javascript:GetCOPicture(" & Trim(dr("BadgeNumber")) & ")><span><strong class='red'>Driver Picture</strong></span></a><br>"
                '********************************************
                sDesc = sDesc & "<a href=javascript:zoomSV(" & dr("Lat") & "," & dr("Lon") & ")><span><strong class='red'>Street View</strong></span></a><br>"
                sURL = "http://maps.google.com/maps?q=" & dr("Lat") & "+" & dr("Lon") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
                sDesc = sDesc & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"
            ElseIf Request.QueryString("Mode") = "AVL" Then
                sDesc = "<H4>Time: " & Trim(dr("VehicleTime")) & "</H4>"
                sDesc = sDesc & "<strong>Date: </strong>" & Trim(dr("VehicleDate")) & "<br>"
                sDesc = sDesc & "<strong>Bus Driver: </strong>" & IIf(IsDBNull(dr("CO_Name")), "", Trim(dr("CO_Name"))) & "<br>"
                sDesc = sDesc & "<strong>Badge#: </strong>" & IIf(IsDBNull(dr("BadgeNumber")), 0, dr("BadgeNumber")) & "<br>"
                sDesc = sDesc & "<strong>Base: </strong>" & IIf(IsDBNull(dr("Base")), "", Trim(dr("Base"))) & "<br>"
                sDesc = sDesc & "<strong>Route#: </strong>" & IIf(IsDBNull(dr("Route")), "", Trim(dr("Route"))) & "<br>"
                sDesc = sDesc & "<strong>Block#: </strong>" & IIf(IsDBNull(dr("Block")), "", Trim(dr("Block"))) & "<br>"
                sDesc = sDesc & "<strong>Trip#: </strong>" & IIf(IsDBNull(dr("TripNumber")), "", Trim(dr("TripNumber"))) & "<br>"
                sDesc = sDesc & "<strong>Bus#: </strong>" & Trim(dr("BusNumber")) & "<br>"
                sDesc = sDesc & "<strong>Speed: </strong>" & IIf(IsDBNull(dr("Speed")), "", Trim(dr("Speed"))) & "<br>"
                sDesc = sDesc & "<strong>Direction: </strong>" & IIf(IsDBNull(dr("Direction")), "", Trim(dr("Direction"))) & "<br>"
                sDesc = sDesc & "<strong>Heading: </strong>" & IIf(IsDBNull(dr("Heading")), "", Trim(dr("Heading"))) & "<br>"
                sDesc = sDesc & "<strong>Status: </strong>" & IIf(IsDBNull(dr("Status")), "", Trim(dr("Status"))) & "<br><br>"
                sDesc = sDesc & "<a href=javascript:zoomSV(" & dr("Lat") & "," & dr("Lon") & ")><span><strong class='red'>Street View</strong></span></a><br>"
                sURL = "http://maps.google.com/maps?q=" & dr("Lat") & "+" & dr("Lon") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
                sDesc = sDesc & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"
            ElseIf Request.QueryString("Mode") = "Maintenance" Then
                sDesc = "<H4>Bus#: " & dr("BusNumber") & "</H4>"
                sDesc = sDesc & "<strong>Date: </strong>" & dr("VehicleDate") & "<br>"
                sDesc = sDesc & "<strong>Time: </strong>" & dr("VehicleTime") & "<br>"

                sDesc = sDesc & "<a href=javascript:zoomSV(" & dr("Lat") & "," & dr("Lon") & ")><span><strong class='red'>Street View</strong></span></a><br>"
                sURL = "http://maps.google.com/maps?q=" & dr("Lat") & "+" & dr("Lon") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
                sDesc = sDesc & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"
            End If

            If Request.QueryString("Mode") <> "Maintenance" Then
                Session("DriverID") = Trim(dr("BadgeNumber"))
            End If

            'Set the Lat/Lon values aside
            dLat = dr("Lat")
            dLon = dr("Lon")

            Dim objDt As New DataTable()

            objDt = Session("tbl")

            Dim objDataRow As DataRow

            ' add a row to the dataset
            objDataRow = objDt.NewRow
            If Request.QueryString("Mode") <> "Maintenance" Then
                objDataRow("Sequence") = Session("Count")
                objDataRow("Desc") = sDesc
                objDataRow("Lat") = dLat
                objDataRow("Lon") = dLon
                objDataRow("Time") = IIf(IsDBNull(dr("VehicleTime")), "", dr("VehicleTime"))
                objDataRow("Date") = IIf(IsDBNull(dr("VehicleDate")), "", dr("VehicleDate"))
                objDataRow("Badge") = IIf(IsDBNull(dr("BadgeNumber")), "", dr("BadgeNumber"))
                objDataRow("Operator") = IIf(IsDBNull(dr("CO_Name")), "", dr("CO_Name"))
                objDataRow("Base") = IIf(IsDBNull(dr("Base")), "", dr("Base"))
                objDataRow("Bus") = IIf(IsDBNull(dr("BusNumber")), "", dr("BusNumber"))
                objDataRow("Route") = IIf(IsDBNull(dr("ROUTE")), "", dr("ROUTE"))
                objDataRow("Block") = IIf(IsDBNull(dr("BLOCK")), "", dr("BLOCK"))
                objDataRow("Status") = IIf(IsDBNull(dr("Status")), "", dr("Status"))
                objDataRow("Speed") = IIf(IsDBNull(dr("Speed")), "", dr("Speed"))
                objDataRow("Direction") = IIf(IsDBNull(dr("Direction")), "", dr("Direction"))
                objDataRow("Heading") = IIf(IsDBNull(dr("Heading")), "", dr("Heading"))
                If Request.QueryString("Mode") = "Route" Then
                    objDataRow("Trip") = dr("TripNumber")
                    objDataRow("TimePoint") = IIf(IsDBNull(dr("TimePoint")), "", dr("TimePoint"))
                    objDataRow("NextTimePoint") = IIf(IsDBNull(dr("NextTimePoint")), "", dr("NextTimePoint"))
                ElseIf Request.QueryString("Mode") = "AVL" Then
                    objDataRow("Trip") = dr("TripNumber")
                ElseIf Request.QueryString("Mode") = "Search" Then
                    objDataRow("Trip") = dr("TripNumber")
                    objDataRow("TimePoint") = IIf(IsDBNull(dr("TimePoint")), "", dr("TimePoint"))
                    objDataRow("TimePointTime") = IIf(IsDBNull(dr("TimePointTime")), "", dr("TimePointTime"))
                    objDataRow("NextTimePoint") = IIf(IsDBNull(dr("NextTimePoint")), "", dr("NextTimePoint"))
                    objDataRow("NextTimePointTime") = IIf(IsDBNull(dr("NextTimePointTime")), "", dr("NextTimePointTime"))
                    objDataRow("Deviation") = IIf(IsDBNull(dr("Deviation")), 0, DateAdd(DateInterval.Minute, dr("Deviation"), dr("NextTimePointTime")))
                    objDataRow("ClosestStop") = IIf(IsDBNull(dr("Closest_Stop")), "", dr("Closest_Stop"))
                End If
            ElseIf Request.QueryString("Mode") = "Maintenance" Then
                objDataRow("Sequence") = 1
                objDataRow("Desc") = sDesc
                objDataRow("Lat") = dLat
                objDataRow("Lon") = dLon
                objDataRow("Time") = dr("VehicleTime")
                objDataRow("Date") = dr("VehicleDate")
                objDataRow("Badge") = ""
                objDataRow("Operator") = ""
                objDataRow("Base") = ""
                objDataRow("Bus") = dr("BusNumber")
                objDataRow("Route") = ""
                objDataRow("Block") = ""
                objDataRow("Status") = ""
                objDataRow("Speed") = ""
                objDataRow("Direction") = ""
                objDataRow("Heading") = ""
                objDataRow("Trip") = ""
                objDataRow("TimePoint") = ""
                objDataRow("NextTimePoint") = ""
            End If

            objDt.Rows.Add(objDataRow)

            Session("tbl") = objDt
            Session("Count") = Session("Count") + 1
            x = x + 1
        Loop

        dr.Close()
        oComm.Connection.Close()

        'If no records exist, redirect and display message
        If x = 0 Then
            oConn.Close()
            oConn.Dispose()
            Response.Redirect("MessageDisplay.aspx?Msg=No Records Exist for this Search Criteria")
            Exit Function
        End If

        'Load Javascript
        LoadJavaScript(dLat, dLon)

FindMyBus_Exit:
        oConn.Close()
        oConn.Dispose()
        Exit Function

FindMyBus_Error:
        Dim sMsg As String = ""

        sMsg = "Error Number: " & Err.Number & vbCrLf & "Description: " & Err.Description & ""
        sMsg = HttpUtility.UrlEncode(sMsg)
        Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")

        FindMyBus = False

        Resume FindMyBus_Exit

    End Function

    Private Sub LoadJavaScript(ByVal dLat As Double, ByVal dLon As Double)
        On Error GoTo LoadJavaScript_Error

        Dim objDt As New DataTable()
        Dim sJScript As String = ""
        Dim i As Integer
        Dim sDesc As String = ""
        Dim sDir As String = ""
        Dim iSeq As Integer
        Dim sName As String = ""
        Dim bValidShapeFile As Boolean = False
        Dim sStr As String = ""
        Dim sMapType As String = ""
        Dim sURL As String = ""

        'This is all of the javascript code that is created each time the page is loaded
        'using the ClientScript.RegisterClientScriptBlock method
        sJScript = "<script type=""text/javascript"">" & vbCrLf

        'Set the Div size that contains the map
        'sJScript = sJScript & "setFrameSize()" & vbCrLf

        sJScript = sJScript & "document.all.side_bar.style.visibility = 'visible'; " & vbCrLf

        'this variable will collect the html which will eventually be placed in the side_bar
        sJScript = sJScript & "var side_bar_html = ""<span class=SideBar>View Details</span><hr class=new1>"";" & vbCrLf

        'arrays to hold copies of the markers and html used by the side_bar
        sJScript = sJScript & "var gmarkers = [];" & vbCrLf

        'A function to create the marker and set up the event window
        sJScript = sJScript & "function createMarker(seq,point,name,html,dir) {" & vbCrLf

        '*7/20/2016 AA - Removed icons and added dynamic icons with labels. SVG does not work with IE**********************************************************************
        'If Request.Browser.Browser = "InternetExplorer" Then
        'sJScript = sJScript & "var image = new google.maps.MarkerImage('images/number_' +  (seq) + '.png');" & vbCrLf
        'Else
        sJScript = sJScript & "var image = 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2238%22%20"
        sJScript = sJScript & "height%3D%2238%22%20viewBox%3D%220%200%2038%2038%22%3E%3Cpath%20fill%3D%22%23808080%22%20stroke%3D%22%23ccc%22%20"
        sJScript = sJScript & "stroke-width%3D%22.5%22%20d%3D%22M34.305%2016.234c0%208.83-15.148%2019.158-15.148%2019.158S3.507%2025.065%203.507%20"
        sJScript = sJScript & "16.1c0-8.505%206.894-14.304%2015.4-14.304%208.504%200%2015.398%205.933%2015.398%2014.438z%22%2F%3E%3C"
        sJScript = sJScript & "text%20transform%3D%22translate%2819%2018.5%29%22%20fill%3D%22%23fff%22%20style%3D%22font-family%3A%20Arial%2C%20"
        sJScript = sJScript & "sans-serif%3Bfont-weight%3Abold%3Btext-align%3Acenter%3B%22%20font-size%3D%2212%22%20text-anchor%3D%22middle%22%3E"
        sJScript = sJScript & "' + seq + '-' + dir + '%3C%2Ftext%3E%3C%2Fsvg%3E';" & vbCrLf
        'End If
        '*End of script for dynamic icons***********************************************************************

        sJScript = sJScript & "var marker = new google.maps.Marker({" & vbCrLf
        sJScript = sJScript & "position: point, " & vbCrLf
        sJScript = sJScript & "animation: google.maps.Animation.DROP, " & vbCrLf
        sJScript = sJScript & "icon: image, " & vbCrLf
        sJScript = sJScript & "optimized: false, " & vbCrLf
        sJScript = sJScript & "map: map});" & vbCrLf
        sJScript = sJScript & "var infowindow = new google.maps.InfoWindow({content: html});" & vbCrLf
        sJScript = sJScript & "google.maps.event.addListener(marker, ""click"", function() {" & vbCrLf
        sJScript = sJScript & "infowindow.open(map,marker);" & vbCrLf
        sJScript = sJScript & "});" & vbCrLf
        'save the info we need to use later for the side_bar
        sJScript = sJScript & "gmarkers.push(marker);" & vbCrLf
        'add a line to the side_bar html
        sJScript = sJScript & "side_bar_html += '<a href=""javascript:myclick(' + (gmarkers.length-1) + ')"">' + seq + ') ' + name + '<\/a><br>';" & vbCrLf
        sJScript = sJScript & "return marker;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'This function picks up the click and opens the corresponding info window
        sJScript = sJScript & "function myclick(i) {" & vbCrLf
        sJScript = sJScript & "google.maps.event.trigger(gmarkers[i], ""click"");" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'create the map
        sJScript = sJScript & "var mapOptions = {" & vbCrLf
        sJScript = sJScript & "zoom: 4," & vbCrLf
        sJScript = sJScript & "panControl: true, " & vbCrLf
        sJScript = sJScript & "zoomControl: true, " & vbCrLf
        sJScript = sJScript & "mapTypeControl: true, " & vbCrLf
        sJScript = sJScript & "scaleControl: true, " & vbCrLf
        sJScript = sJScript & "streetViewControl: true, " & vbCrLf
        sJScript = sJScript & "overviewMapControl: true, " & vbCrLf
        sJScript = sJScript & "center: new google.maps.LatLng(" & dLat & ", " & dLon & "), " & vbCrLf
        sJScript = sJScript & "mapTypeId: google.maps.MapTypeId.ROADMAP}" & vbCrLf
        sJScript = sJScript & "var map = new google.maps.Map(document.getElementById(""map""), mapOptions);" & vbCrLf

        'add the points   
        objDt = Session("tbl")
        'Set the map zoom level/boundaries
        sJScript = sJScript & "var bounds = new google.maps.LatLngBounds();" & vbCrLf

        For i = 0 To objDt.Rows.Count - 1
            iSeq = CInt(objDt.Rows(i).Item("Sequence"))
            sDir = IIf(Left(CStr(objDt.Rows(i).Item("Direction")), 1) = "", "N/A", Left(CStr(objDt.Rows(i).Item("Direction")), 1))
            sDesc = IIf(CStr(objDt.Rows(i).Item("Desc")) = "", "N/A", CStr(objDt.Rows(i).Item("Desc")))
            dLat = CDbl(objDt.Rows(i).Item("Lat"))
            dLon = CDbl(objDt.Rows(i).Item("Lon"))
            If Request.QueryString("Mode") = "Route" Then
                sName = objDt.Rows(i).Item("Block")
            Else
                sName = objDt.Rows(i).Item("Time")
            End If

            sJScript = sJScript & "var point = new google.maps.LatLng(" & dLat & ", " & dLon & ");" & vbCrLf
            sJScript = sJScript & "var marker = createMarker(" & CStr(iSeq) & ", point, """ & sName & """, """ & sDesc & """, """ & sDir & """)" & vbCrLf
            sJScript = sJScript & "marker.setMap(map);" & vbCrLf
            'Set the Zoom level to encompass all the points
            sJScript = sJScript & "bounds.extend(point);" & vbCrLf
        Next

        'If zoom level is greater > 16 than set to 16
        If objDt.Rows.Count = 1 Then
            sJScript = sJScript & "map.setZoom(16);" & vbCrLf
            sJScript = sJScript & "map.setCenter(point);" & vbCrLf
        Else
            sJScript = sJScript & "map.fitBounds(bounds);" & vbCrLf
        End If

        'Add traffic Overlay
        If Request.QueryString("Mode") <> "AVL" Then
            sJScript = sJScript & "var trafficLayer = new google.maps.TrafficLayer();" & vbCrLf
            sJScript = sJScript & "trafficLayer.setMap(map);" & vbCrLf
            'Hide the traffic layer on-load
            sJScript = sJScript & "trafficLayer.setMap(null);" & vbCrLf
        End If

        'Add Shapefile / Polyline
        If Request.QueryString("Route") = "yes" Then
            sJScript = sJScript & "var routeCoord =[" & GetShapeFile() & "];" & vbCrLf
            sJScript = sJScript & "var polyOptions = {" & vbCrLf
            sJScript = sJScript & "path: routeCoord," & vbCrLf
            sJScript = sJScript & "strokeColor:  '#ff0000'," & vbCrLf
            sJScript = sJScript & "strokeOpacity: .5," & vbCrLf
            sJScript = sJScript & "strokeWeight: 5}" & vbCrLf
            sJScript = sJScript & "poly = new google.maps.Polyline(polyOptions);" & vbCrLf
            sJScript = sJScript & "poly.setMap(map);" & vbCrLf

            bValidShapeFile = True
        End If

        'put the assembled side_bar_html contents into the side_bar div
        'Add the Traffic and Route buttons as required
        If bValidShapeFile And Request.QueryString("Mode") <> "AVL" Then
            sStr = "'<br><hr class=new1><input class=""btn"" type=""button"" value=""Route"" onClick=""toggleRoute();""/>"
            sStr = sStr & "<p><hr class=new1><input class=""btn"" type=""button"" value=""Traffic"" onClick=""toggleTraffic();""/></p>';" & vbCrLf
            sJScript = sJScript & "document.getElementById(""side_bar"").innerHTML = side_bar_html + " & sStr & vbCrLf
        ElseIf Not bValidShapeFile And Request.QueryString("Mode") <> "AVL" Then
            sStr = sStr & "'<p><hr class=new1><input class=""btn"" type=""button"" value=""Traffic"" onClick=""toggleTraffic();""/></p>';" & vbCrLf
            sJScript = sJScript & "document.getElementById(""side_bar"").innerHTML = side_bar_html + " & sStr & vbCrLf
        ElseIf Request.QueryString("Mode") = "AVL" Then
            'sStr = "'<br><hr class=new1><input class=""btn"" type=""button"" value=""Route"" style=""border: 0; width:90%"" onClick=""toggleRoute();""/>"
            'sStr = sStr & "<p><hr class=new1><input class=""btn"" type=""button"" value=""CO Picture"" style=""border: 0; width:90%"" onClick=""javascript:OpenCOPicture();""/></p>';" & vbCrLf
            sStr = "'<br><hr><input class=""btn"" type=""button"" value=""Route"" onClick=""toggleRoute();""/>';"
            sJScript = sJScript & "document.getElementById(""side_bar"").innerHTML = side_bar_html + " & sStr & vbCrLf
        Else
            sJScript = sJScript & "document.getElementById(""side_bar"").innerHTML = side_bar_html;" & vbCrLf
        End If

        'Create the toggleTraffic function
        If Request.QueryString("Mode") <> "AVL" Then
            sJScript = sJScript & "var toggleState = 0;" & vbCrLf
            sJScript = sJScript & "function toggleTraffic() {" & vbCrLf
            sJScript = sJScript & "if (toggleState == 1) {" & vbCrLf
            sJScript = sJScript & "trafficLayer.setMap(null)" & vbCrLf
            sJScript = sJScript & "toggleState = 0;" & vbCrLf
            sJScript = sJScript & "} else {" & vbCrLf
            sJScript = sJScript & "trafficLayer.setMap(map);" & vbCrLf
            sJScript = sJScript & "toggleState = 1;" & vbCrLf
            sJScript = sJScript & "}" & vbCrLf
            sJScript = sJScript & "}" & vbCrLf
        End If

        'Create the toggleRoute function
        If Request.QueryString("Route") = "yes" Then
            sJScript = sJScript & "var routeToggleState = 0;" & vbCrLf
            sJScript = sJScript & "function toggleRoute() {" & vbCrLf
            sJScript = sJScript & "if (routeToggleState == 1) {" & vbCrLf
            sJScript = sJScript & "poly.setMap(null);" & vbCrLf
            sJScript = sJScript & "routeToggleState = 0;" & vbCrLf
            sJScript = sJScript & "} else {" & vbCrLf
            sJScript = sJScript & "poly.setMap(map);" & vbCrLf
            sJScript = sJScript & "routeToggleState = 1;" & vbCrLf
            sJScript = sJScript & "}" & vbCrLf
            sJScript = sJScript & "}" & vbCrLf
        End If

        'Function to breakout the Street View window
        sJScript = sJScript & "function zoomSV(vLat, vLong) " & vbCrLf
        sJScript = sJScript & "{" & vbCrLf
        sJScript = sJScript & "varStr = 'Lat=' + vLat + '&Long=' + vLong" & vbCrLf
        sJScript = sJScript & "varURL = 'ZoomSV.aspx?' + varStr;" & vbCrLf
        sJScript = sJScript & "objWin = window.open(varURL, '', 'left=10,top=10,toolbar=false,status=false,directories=false,menubar=false,scrollbars=no,resizable=yes,copyhistory=false,width=825,height=525');" & vbCrLf
        sJScript = sJScript & "}  " & vbCrLf

        '****************************************************************************************
        'A function to create the marker and set up the event window for Bus Stop Alerts
        sJScript = sJScript & "function createConstructionMarker(point,html,desc) {" & vbCrLf
        sJScript = sJScript & "var image = new google.maps.MarkerImage('images/construction.png');" & vbCrLf
        sJScript = sJScript & "var marker = new google.maps.Marker({" & vbCrLf
        sJScript = sJScript & "position: point, " & vbCrLf
        sJScript = sJScript & "animation: google.maps.Animation.DROP, " & vbCrLf
        sJScript = sJScript & "icon: image, " & vbCrLf
        sJScript = sJScript & "map: map});" & vbCrLf
        sJScript = sJScript & "var infowindow = new google.maps.InfoWindow({content: html});" & vbCrLf
        sJScript = sJScript & "google.maps.event.addListener(marker, ""click"", function() {" & vbCrLf
        sJScript = sJScript & "infowindow.open(map,marker);" & vbCrLf
        sJScript = sJScript & "});" & vbCrLf
        'save the info we need to use later for the side_bar
        sJScript = sJScript & "gmarkers.push(marker);" & vbCrLf
        'add a line to the Detours Div
        sJScript = sJScript & "document.getElementById(""Detours"").innerHTML += '<a href=""javascript:myclick(' + (gmarkers.length-1) + ')"">' + desc + '<\/a><br>';" & vbCrLf
        sJScript = sJScript & "return marker;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'This function picks up the click and opens the corresponding info window
        sJScript = sJScript & "function myclick(i) {" & vbCrLf
        sJScript = sJScript & "google.maps.event.trigger(gmarkers[i], ""click"");" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'Look for Bus Stop Status info
        If Request.QueryString("Route") = "yes" Then
            sSQL = "SELECT * FROM qselBusStopStatusForBusLocator WHERE [RTE] = " & CInt(objDt.Rows(0).Item("Route")) & ""
            Dim sConn6 = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
            Dim oConn6 As New SqlConnection(sConn6)
            Dim oComm6 As New SqlCommand(sSQL, oConn6)
            oComm6.CommandType = CommandType.Text

            oConn6.Open()

            Dim dr6 As SqlDataReader

            dr6 = oComm6.ExecuteReader()
            Dim sStatus As String = ""
            Dim sStr1 As String = ""
            i = 0
            'Display return value
            Do While dr6.Read()

                If i = 0 Then sJScript = sJScript & "document.getElementById(""Detours"").innerHTML += ""<hr class=new1><br><div class=SideBar><u>Bus Stop Alert</u></div><br>""" & vbCrLf

                sStr1 = "<div class=red><u>Bus Stop Alert</u></div>"
                sStr1 = sStr1 & "<div><span><strong>Stop ID: </strong></span>" & dr6("BusStopID") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>Date Posted: </strong></span>" & dr6("CreatedDate") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>Start Date: </strong></span>" & dr6("StartDate") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>End Date: </strong></span>" & dr6("EndDate") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>Date Last Checked: </strong></span>" & dr6("DateLastChecked") & "</div>"
                sStr1 = sStr1 & "<div><strong>St/X St: </strong>" & dr6("STREET") & "/" & dr6("CrossStreet") & "</div>"
                sStr1 = sStr1 & "<div><strong>Dir: </strong>" & dr6("Direction") & "</div>"

                sDesc = "Stop ID# " & dr6("BusStopID")

                'sStr1 = sStr1 & "<div><strong>Status: </strong>" & sStatus & "</div>"
                sStr1 = sStr1 & "<div><strong>Notes: </strong>" & dr6("Description") & "</div><br>"

                '***
                sStr1 = sStr1 & "<a href=javascript:zoomSV(" & dr6("Lat") & "," & dr6("Long") & ")><span><strong class='red'>Street View</strong></span></a><br>"
                sURL = "http://maps.google.com/maps?q=" & dr6("Lat") & "+" & dr6("Long") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
                sStr1 = sStr1 & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"
                '***
                sJScript = sJScript & "var point = new google.maps.LatLng(" & dr6("Lat") & ", " & dr6("Long") & ");" & vbCrLf
                sJScript = sJScript & "var marker = createConstructionMarker(point, """ & sStr1 & """, """ & sDesc & """)" & vbCrLf
                sJScript = sJScript & "marker.setMap(map);" & vbCrLf
                i = i + 1
            Loop

            dr6.Close()
            oConn6.Close()
        End If
        '*******End of Bus Stop Alerts*******************************************************************************

        '******Start of Bus Stop Info**********************************************************************************
        'A function to create the marker and set up the event window for Bus Stop Alerts
        sJScript = sJScript & "function createBusStopMarker(point,html) {" & vbCrLf
        sJScript = sJScript & "var image = new google.maps.MarkerImage('images/dot.png');" & vbCrLf
        sJScript = sJScript & "var marker = new google.maps.Marker({" & vbCrLf
        sJScript = sJScript & "position: point, " & vbCrLf
        sJScript = sJScript & "icon: image, " & vbCrLf
        sJScript = sJScript & "map: map});" & vbCrLf
        sJScript = sJScript & "var infowindow = new google.maps.InfoWindow({content: html});" & vbCrLf
        sJScript = sJScript & "google.maps.event.addListener(marker, ""click"", function() {" & vbCrLf
        sJScript = sJScript & "infowindow.open(map,marker);" & vbCrLf
        sJScript = sJScript & "});" & vbCrLf
        'save the info we need to use later for the side_bar
        sJScript = sJScript & "gmarkers.push(marker);" & vbCrLf
        sJScript = sJScript & "return marker;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'This function picks up the click and opens the corresponding info window
        sJScript = sJScript & "function myclick(i) {" & vbCrLf
        sJScript = sJScript & "google.maps.event.trigger(gmarkers[i], ""click"");" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'Look for Bus Stop Status info
        If Request.QueryString("Route") = "yes" Then
            sSQL = "SELECT * FROM vwBusStopsByTrip WHERE [trip_id] = " & CInt(objDt.Rows(0).Item("Trip")) & ""
            Dim sConn7 = System.Configuration.ConfigurationManager.ConnectionStrings("GTFSConnStr").ConnectionString
            Dim oConn7 As New SqlConnection(sConn7)
            Dim oComm7 As New SqlCommand(sSQL, oConn7)
            oComm7.CommandType = CommandType.Text

            oConn7.Open()

            Dim dr7 As SqlDataReader

            dr7 = oComm7.ExecuteReader()
            Dim sStatus As String = ""
            Dim sStr2 As String = ""
            i = 0
            'Display return value
            Do While dr7.Read()
                sStr2 = "<div class=red><u>Bus Stop ID# " & dr7("stop_id") & "</u></div>"
                sStr2 = sStr2 & "<div><span><strong>Bus Stop Name: </strong></span>" & dr7("stop_name") & "</div>"
                sStr2 = sStr2 & "<div><span><strong>Route Stop Sequence: </strong></span>" & dr7("stop_sequence") & "</div>"
                sStr2 = sStr2 & "<div><span><strong>Scheduled Depart Time: </strong></span>" & dr7("departure_time") & "</div>"

                sJScript = sJScript & "var point = new google.maps.LatLng(" & dr7("stop_lat") & ", " & dr7("stop_lon") & ");" & vbCrLf
                sJScript = sJScript & "var marker = createBusStopMarker(point, """ & sStr2 & """)" & vbCrLf
                sJScript = sJScript & "marker.setMap(map);" & vbCrLf
                i = i + 1
            Loop

            dr7.Close()
            oConn7.Close()
        End If
        '*********End of Bus Stop Info*****************************************************************************
        sJScript = sJScript & "</scr" & "ipt>"
        ClientScript.RegisterClientScriptBlock(GetType(MyBus), "NewWin", sJScript)

LoadJavaScript_Exit:
        Exit Sub

LoadJavaScript_Error:
        Dim sMsg As String = ""

        sMsg = "Error Number: " & Err.Number & vbCrLf & "Description: " & Err.Description & ""

        sMsg = HttpUtility.UrlEncode(sMsg)
        Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")

        Resume LoadJavaScript_Exit

    End Sub

    Public Function GetStatus(ByVal sStatus As String) As String
        On Error Resume Next

        'Convert the status code to status from the AVL dataset
        Select Case sStatus
            Case "N"
                GetStatus = "Normal"
            Case "E"
                GetStatus = "Emergency"
            Case "U"
                GetStatus = "Unknown Location"
            Case "A"
                GetStatus = "Ahead of schedule"
            Case "B"
                GetStatus = "Behind Schedule"
            Case "O"
                GetStatus = "Off-Route"
            Case "M"
                GetStatus = "Mechanical Failure Discrete"
            Case "D"
                GetStatus = "Detoured"
            Case "R"
                GetStatus = "RSA Suspended"
            Case Else
                GetStatus = "N/A"
        End Select

    End Function

    Private Function GetShapePatternID() As Integer
        On Error Resume Next

        Dim sStr As String = ""
        Dim sSQL As String = ""
        Dim objDt As New DataTable()

        GetShapePatternID = 0
        objDt = Session("tbl")

        sSQL = "SELECT shape_id FROM dbo.tblTrips WHERE trip_id = " & CInt(objDt.Rows(0).Item("Trip")) & ""

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            GetShapePatternID = dr("shape_id")
        Loop

    End Function

    Private Function GetShapePatternID_GFI() As Integer
        On Error Resume Next

        Dim sStr As String = ""
        Dim sSQL As String = ""
        Dim iDays As Integer
        Dim sDays As String = ""
        Dim iBlock As Integer, iRoute As Integer
        Dim sTime As String = ""

        GetShapePatternID_GFI = 0

        Dim objDt As New DataTable()

        objDt = Session("tblGFI")

        Dim drFilter() As DataRow

        Dim sCriteria As String = "Sequence = 1"

        drFilter = objDt.Select(sCriteria)

        For intIndex As Integer = 0 To (drFilter.Length - 1)
            sDays = CDate(drFilter(intIndex)("Date").ToString).DayOfWeek
        Next

        For intIndex As Integer = 0 To (drFilter.Length - 1)
            If Request.QueryString("Route") = "yes" Then
                iRoute = CInt(drFilter(intIndex)("Route"))
            Else
                iBlock = CInt(drFilter(intIndex)("Block"))
            End If
        Next

        For intIndex As Integer = 0 To (drFilter.Length - 1)
            sTime = CStr(drFilter(intIndex)("Time").ToString)
        Next

        Select Case sDays
            Case 1 To 5
                iDays = 12345
            Case 0
                iDays = 7
            Case 6
                iDays = 6
        End Select

        sSQL = "SELECT TOP 1 Pattern FROM tblBlockPatterns "
        If Request.QueryString("Route") = "yes" Then
            sSQL = sSQL & "WHERE (Route = " & iRoute & ") "
        Else
            sSQL = sSQL & "WHERE (Busrun = " & iBlock & ") "
        End If
        sSQL = sSQL & "AND (Days = " & iDays & ") "
        sSQL = sSQL & "AND (StartTime <= '1899-12-30 " & sTime & "' "
        sSQL = sSQL & "AND EndTime >= '1899-12-30 " & sTime & "')"

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            GetShapePatternID_GFI = dr("Pattern")
        Loop

    End Function
    Private Function GetShapeFile() As String
        On Error Resume Next

        Dim sStr As String = ""
        Dim sSQL As String = ""
        Dim iShapeFileID As Integer

        GetShapeFile = ""

        If Request.QueryString("Mode") = "GFI" Then
            iShapeFileID = GetShapePatternID_GFI()
        Else
            iShapeFileID = GetShapePatternID()
        End If

        If iShapeFileID = 0 Then Exit Function

        sSQL = "SELECT shape_pt_sequence, shape_pt_lat, shape_pt_lon FROM tblShapeFile WHERE shape_id = " & iShapeFileID & " ORDER BY shape_pt_sequence"
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            sStr = sStr & "new google.maps.LatLng(" & dr("shape_pt_lat") & "," & dr("shape_pt_lon") & "), " & vbCrLf
            'sStr = sStr & "new GLatLng(" & dr("shape_pt_lat") & "," & dr("shape_pt_lon") & "), " & vbCrLf
        Loop

        sStr = Left(sStr, Len(sStr) - 4)
        GetShapeFile = sStr

    End Function

    Public Function FindMyBusGFI(ByVal sSQL As String) As Boolean
        On Error GoTo FindMyBusGFI_Error

        'Determine if this requires a new dataset
        If Session("tblGFI") Is Nothing Then
            MakeTableGFI()
        End If

        FindMyBusGFI = False
        Dim sDesc As String = ""
        Dim dLat As Double
        Dim dLon As Double
        Dim x As Integer
        Dim fdDate As String
        Dim dDate As DateTime
        Dim fdTime As String
        Dim dTime As DateTime
        Dim sURL As String
        Dim iMinutes As Integer
        Dim iSeconds As Integer
        Dim dScheduledDepartTime As Date
        Dim sLatLon As String = ""
        Dim sStatus As String = ""
        Dim sCOName As String = ""
        Dim sCOBase As String = ""

        'Set the connection to the AVL database      
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text
        oConn.Open()

        Dim dr As SqlDataReader
        dr = oComm.ExecuteReader()

        x = 0
        Do While dr.Read()
            'Set the time portion of the date string 
            dTime = dr("ARRIVE_TIME")
            fdTime = dTime.ToString("HH:mm:ss")

            'Set the date portion of the date string
            dDate = dr("TRANSACTION_DATE")
            fdDate = dDate.ToString("MM/dd/yyyy")

            sDesc = ""
            sDesc = "<H4>Time: " & fdTime & "</H4>"
            sDesc = "<strong>Date: </strong>" & fdDate & "<br>"
            sDesc = sDesc & "<strong>Badge#: </strong>" & dr("Badge") & "<br>"
            If IsNumeric(dr("Badge")) Then
                sDesc = sDesc & "<strong>Name: </strong>" & sCOName & "<br>"
                sDesc = sDesc & "<strong>Base: </strong>" & sCOBase & "<br>"
            Else
                sDesc = sDesc & "<strong>Name: </strong>N/A<br>"
            End If
            sDesc = sDesc & "<strong>Route: </strong>" & dr("Route") & "<br>"
            sDesc = sDesc & "<strong>Bus Number: </strong>" & CInt(dr("Bus")) & "<br>"
            sDesc = sDesc & "<strong>Bus Stop#: </strong>" & CInt(dr("STOP_NO")) & "<br>"
            sDesc = sDesc & "<strong>Time Point: </strong>" & dr("TP") & "<br>"
            sDesc = sDesc & "<strong>Arrival Time: </strong>" & dr("ARRIVE_TIME") & "<br>"
            If Not IsDBNull(dr("DEPART_DIFF")) Then
                iMinutes = DatePart("n", dr("DEPART_DIFF")) * 60
                iSeconds = DatePart("s", dr("DEPART_DIFF")) + iMinutes
                dScheduledDepartTime = DateAdd("s", -(iSeconds), dr("DEPART_TIME"))
                sDesc = sDesc & "<strong>Scheduled Depart Time: </strong>" & dScheduledDepartTime.ToString("HH:mm:ss") & "" & "<br>"
            End If
            sDesc = sDesc & "<strong>Actual Departure: </strong>" & dr("DEPART_TIME") & "<br>"
            sDesc = sDesc & "<strong>Difference: </strong>" & dr("DEPART_DIFF") & "<br>"
            sDesc = sDesc & "<strong>Dwell Time: </strong>" & dr("DWELL_TIME") & "<br>"
            sDesc = sDesc & "<strong>Location: </strong>" & Replace(dr("STREET"), "&", "And", 1) & "/" & Replace(dr("CROSS_STREET"), "&", "And", 1) & "<br>"
            sDesc = sDesc & "<strong>Block#: </strong>" & dr("BUS_RUN") & "<br>"
            sDesc = sDesc & "<strong>Direction: </strong>" & dr("Direction") & "<br>"
            sDesc = sDesc & "<strong>Boardings: </strong>" & dr("BOARDINGS") & "<br>"
            sDesc = sDesc & "<strong>Arrival Source: </strong>" & dr("ARRIVE_SOURCE") & "<br>"
            sDesc = sDesc & "<strong>Depart Source: </strong>" & dr("DEPART_SOURCE") & "<br><br>"

            sLatLon = GetLatLon(dr("STOP_NO"))
            dLat = CDbl(Left(sLatLon, InStr(sLatLon, ",") - 1))
            dLon = CDbl(Right(sLatLon, Len(sLatLon) - Len(dLat) - 1))
            sDesc = sDesc & "<a href=javascript:zoomSV(" & dLat & "," & dLon & ")><span><strong class='red'>Street View</strong></span></a><br>"
            sURL = "http://maps.google.com/maps?q=" & dLat & "+" & dLon & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
            sDesc = sDesc & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"

            If Not IsDBNull(dr("DEPART_DIFF")) Then
                If dr("DEPART_DIFF") > "00:03:00" Then
                    sStatus = "Late"
                ElseIf dr("DEPART_DIFF") < "00:00:00" Then
                    sStatus = "Hot"
                Else
                    sStatus = "Normal"
                End If
            Else
                sStatus = "Normal"
            End If

            Dim objDtGFI As New DataTable()

            objDtGFI = Session("tblGFI")

            Dim objDataRowGFI As DataRow

            ' add a row to the dataset
            objDataRowGFI = objDtGFI.NewRow
            objDataRowGFI("Sequence") = Session("CountGFI")
            objDataRowGFI("Desc") = sDesc
            objDataRowGFI("Lat") = CDbl(dLat)
            objDataRowGFI("Lon") = CDbl(dLon)
            objDataRowGFI("Time") = CStr(fdTime)
            objDataRowGFI("Date") = CStr(fdDate)
            objDataRowGFI("Badge") = CStr(dr("Badge"))
            objDataRowGFI("Operator") = sCOName
            objDataRowGFI("Base") = sCOBase
            objDataRowGFI("Bus") = CInt(dr("Bus"))
            objDataRowGFI("Route") = dr("Route")
            objDataRowGFI("StopID") = dr("STOP_NO")
            objDataRowGFI("TimePoint") = dr("TP")
            objDataRowGFI("ArrivalTime") = dr("ARRIVE_TIME")
            objDataRowGFI("ScheduledDepartTime") = dScheduledDepartTime
            objDataRowGFI("ActualDeparture") = dr("DEPART_TIME")
            objDataRowGFI("Difference") = dr("DEPART_DIFF")
            objDataRowGFI("DwellTime") = dr("DWELL_TIME")
            objDataRowGFI("Location") = Replace(dr("STREET"), "&", "And", 1) & "/" & Replace(dr("CROSS_STREET"), "&", "And", 1)
            objDataRowGFI("Block") = dr("BUS_RUN")
            objDataRowGFI("Direction") = dr("Direction")
            objDataRowGFI("Boardings") = dr("BOARDINGS")
            objDataRowGFI("ArrivalSource") = dr("ARRIVE_SOURCE")
            objDataRowGFI("DepartSource") = dr("DEPART_SOURCE")
            objDataRowGFI("Status") = sStatus
            objDtGFI.Rows.Add(objDataRowGFI)

            Session("tblGFI") = objDtGFI
            Session("CountGFI") = Session("CountGFI") + 1
            x = x + 1
        Loop

        dr.Close()
        oComm.Connection.Close()

        'If no records exist, redirect and display message
        If x = 0 Then
            Response.Redirect("MessageDisplay.aspx?Msg=No Records Exist for this GFI Search Criteria")
            Exit Function
        End If

        'Load Javascript
        LoadJavaScriptGFI(dLat, dLon)

FindMyBusGFI_Exit:
        oConn.Close()
        oConn.Dispose()
        Exit Function

FindMyBusGFI_Error:
        Dim sMsg As String = ""

        sMsg = "Error Number: " & Err.Number & vbCrLf & "Description: " & Err.Description & ""
        sMsg = HttpUtility.UrlEncode(sMsg)
        Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")

        FindMyBusGFI = False

        Resume FindMyBusGFI_Exit

    End Function

    Private Function GetLatLon(ByVal iBusStopID As Integer) As String
        Dim sSql As String

        GetLatLon = ""

        sSql = ""
        sSql = "SELECT * FROM qselLatLon WHERE OCTA_ID = " & iBusStopID & ""
        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSql, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            GetLatLon = Trim(dr("Lat")) & ", " & Trim(dr("Long"))
        Loop

        oConn.Close()

    End Function

    Private Sub MakeTableGFI()

        ' Create new DataTable instance.
        ' Create a new table everytime the criteria is changed
        Dim tbl As DataTable = New DataTable("tblGFIBusLocation")

        tbl.Columns.Add("Sequence", GetType(Integer))
        tbl.Columns.Add("Desc", GetType(String))
        tbl.Columns.Add("Lat", GetType(Double))
        tbl.Columns.Add("Lon", GetType(Double))
        tbl.Columns.Add("Time", GetType(String))
        tbl.Columns.Add("Date", GetType(Date))
        tbl.Columns.Add("Badge", GetType(String))
        tbl.Columns.Add("Operator", GetType(String))
        tbl.Columns.Add("Base", GetType(String))
        tbl.Columns.Add("Bus", GetType(String))
        tbl.Columns.Add("Route", GetType(String))
        tbl.Columns.Add("StopID", GetType(String))
        tbl.Columns.Add("TimePoint", GetType(String))
        tbl.Columns.Add("ArrivalTime", GetType(String))
        tbl.Columns.Add("ScheduledDepartTime", GetType(String))
        tbl.Columns.Add("ActualDeparture", GetType(String))
        tbl.Columns.Add("Difference", GetType(String))
        tbl.Columns.Add("DwellTime", GetType(String))
        tbl.Columns.Add("Location", GetType(String))
        tbl.Columns.Add("Block", GetType(String))
        tbl.Columns.Add("Direction", GetType(String))
        tbl.Columns.Add("Boardings", GetType(String))
        tbl.Columns.Add("ArrivalSource", GetType(String))
        tbl.Columns.Add("DepartSource", GetType(String))
        tbl.Columns.Add("Status", GetType(String))

        Session("tblGFI") = tbl
        Session("CountGFI") = 1

    End Sub

    Private Sub LoadJavaScriptGFI(ByVal dLat As Double, ByVal dLon As Double)
        On Error GoTo LoadJavaScriptGFI_Error

        Dim objDt As New DataTable()
        Dim sJScript As String = ""
        Dim i As Integer
        Dim sDesc As String = ""
        Dim sDir As String = ""
        Dim iSeq As Integer
        Dim sName As String = ""
        Dim bValidShapeFile As Boolean = False
        Dim sStr As String = ""
        Dim sMapType As String = ""
        Dim sURL As String = ""

        'This is all of the javascript code that is created each time the page is loaded
        'using the ClientScript.RegisterClientScriptBlock method
        sJScript = "<script type=""text/javascript"">" & vbCrLf

        'Set the Div size that contains the map
        'sJScript = sJScript & "setFrameSize()" & vbCrLf

        sJScript = sJScript & "document.all.side_bar.style.visibility = 'visible'; " & vbCrLf

        'this variable will collect the html which will eventually be placed in the side_bar
        sJScript = sJScript & "var side_bar_html = ""<span class=SideBar>View Details</span><hr class=new1>"";" & vbCrLf

        'arrays to hold copies of the markers and html used by the side_bar
        sJScript = sJScript & "var gmarkers = [];" & vbCrLf

        'A function to create the marker and set up the event window
        'sJScript = sJScript & "function createMarker(seq,point,name,html) {" & vbCrLf
        sJScript = sJScript & "function createMarker(seq,point,name,html,dir) {" & vbCrLf

        '*7/20/2016 AA - Removed icons and added dynamic icons with labels**********************************************************************
        'If Request.Browser.Browser = "InternetExplorer" Then
        'sJScript = sJScript & "var image = new google.maps.MarkerImage('images/number_' +  (seq) + '.png');" & vbCrLf
        'Else
        sJScript = sJScript & "var image = 'data:image/svg+xml,%3Csvg%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20width%3D%2238%22%20"
        sJScript = sJScript & "height%3D%2238%22%20viewBox%3D%220%200%2038%2038%22%3E%3Cpath%20fill%3D%22%23808080%22%20stroke%3D%22%23ccc%22%20"
        sJScript = sJScript & "stroke-width%3D%22.5%22%20d%3D%22M34.305%2016.234c0%208.83-15.148%2019.158-15.148%2019.158S3.507%2025.065%203.507%20"
        sJScript = sJScript & "16.1c0-8.505%206.894-14.304%2015.4-14.304%208.504%200%2015.398%205.933%2015.398%2014.438z%22%2F%3E%3C"
        sJScript = sJScript & "text%20transform%3D%22translate%2819%2018.5%29%22%20fill%3D%22%23fff%22%20style%3D%22font-family%3A%20Arial%2C%20"
        sJScript = sJScript & "sans-serif%3Bfont-weight%3Abold%3Btext-align%3Acenter%3B%22%20font-size%3D%2212%22%20text-anchor%3D%22middle%22%3E"
        sJScript = sJScript & "' + seq + '-' + dir + '%3C%2Ftext%3E%3C%2Fsvg%3E';" & vbCrLf
        'sJScript = sJScript & "' + seq + '%3C%2Ftext%3E%3C%2Fsvg%3E';" & vbCrLf
        'End If
        '*End of script for dynamic icons***********************************************************************

        sJScript = sJScript & "var marker = new google.maps.Marker({" & vbCrLf
        sJScript = sJScript & "position: point, " & vbCrLf
        sJScript = sJScript & "animation: google.maps.Animation.DROP, " & vbCrLf
        sJScript = sJScript & "icon: image, " & vbCrLf
        sJScript = sJScript & "map: map});" & vbCrLf
        sJScript = sJScript & "var infowindow = new google.maps.InfoWindow({content: html});" & vbCrLf
        sJScript = sJScript & "google.maps.event.addListener(marker, ""click"", function() {" & vbCrLf
        sJScript = sJScript & "infowindow.open(map,marker);" & vbCrLf
        sJScript = sJScript & "});" & vbCrLf
        'save the info we need to use later for the side_bar
        sJScript = sJScript & "gmarkers.push(marker);" & vbCrLf
        'add a line to the side_bar html
        sJScript = sJScript & "side_bar_html += '<a href=""javascript:myclick(' + (gmarkers.length-1) + ')"">' + seq + ') ' + name + '<\/a><br>';" & vbCrLf
        sJScript = sJScript & "return marker;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'This function picks up the click and opens the corresponding info window
        sJScript = sJScript & "function myclick(i) {" & vbCrLf
        sJScript = sJScript & "google.maps.event.trigger(gmarkers[i], ""click"");" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'create the map
        sJScript = sJScript & "var mapOptions = {" & vbCrLf
        sJScript = sJScript & "zoom: 4," & vbCrLf
        sJScript = sJScript & "panControl: true, " & vbCrLf
        sJScript = sJScript & "zoomControl: true, " & vbCrLf
        sJScript = sJScript & "mapTypeControl: true, " & vbCrLf
        sJScript = sJScript & "scaleControl: true, " & vbCrLf
        sJScript = sJScript & "streetViewControl: true, " & vbCrLf
        sJScript = sJScript & "overviewMapControl: true, " & vbCrLf
        sJScript = sJScript & "center: new google.maps.LatLng(" & dLat & ", " & dLon & "), " & vbCrLf
        sJScript = sJScript & "mapTypeId: google.maps.MapTypeId.ROADMAP}" & vbCrLf
        sJScript = sJScript & "var map = new google.maps.Map(document.getElementById(""map""), mapOptions);" & vbCrLf

        'add the points   
        objDt = Session("tblGFI")
        'Set the map zoom level/boundaries
        sJScript = sJScript & "var bounds = new google.maps.LatLngBounds();" & vbCrLf

        For i = 0 To objDt.Rows.Count - 1
            iSeq = CInt(objDt.Rows(i).Item("Sequence"))
            sDir = Left(CStr(objDt.Rows(i).Item("Direction")), 1)
            sDesc = CStr(objDt.Rows(i).Item("Desc"))
            dLat = CDbl(objDt.Rows(i).Item("Lat"))
            dLon = CDbl(objDt.Rows(i).Item("Lon"))
            sName = objDt.Rows(i).Item("Time")

            sJScript = sJScript & "var point = new google.maps.LatLng(" & dLat & ", " & dLon & ");" & vbCrLf
            'sJScript = sJScript & "var marker = createMarker(" & iSeq & ", point, """ & sName & """, """ & sDesc & """)" & vbCrLf
            sJScript = sJScript & "var marker = createMarker(" & CStr(iSeq) & ", point, """ & sName & """, """ & sDesc & """, """ & sDir & """)" & vbCrLf
            sJScript = sJScript & "marker.setMap(map);" & vbCrLf
            'Set the Zoom level to encompass all the points
            sJScript = sJScript & "bounds.extend(point);" & vbCrLf
        Next

        'If zoom level is greater > 16 than set to 16
        If objDt.Rows.Count = 1 Then
            sJScript = sJScript & "map.setZoom(16);" & vbCrLf
            sJScript = sJScript & "map.setCenter(point);" & vbCrLf
        Else
            sJScript = sJScript & "map.fitBounds(bounds);" & vbCrLf
        End If

        'Add Shapefile / Polyline
        sJScript = sJScript & "var routeCoord =[" & GetShapeFile() & "];" & vbCrLf
        sJScript = sJScript & "var polyOptions = {" & vbCrLf
        sJScript = sJScript & "path: routeCoord," & vbCrLf
        sJScript = sJScript & "strokeColor:  '#ff0000'," & vbCrLf
        sJScript = sJScript & "strokeOpacity: .5," & vbCrLf
        sJScript = sJScript & "strokeWeight: 5}" & vbCrLf
        sJScript = sJScript & "poly = new google.maps.Polyline(polyOptions);" & vbCrLf
        sJScript = sJScript & "poly.setMap(map);" & vbCrLf

        bValidShapeFile = True

        'put the assembled side_bar_html contents into the side_bar div
        'Add the Traffic and Route buttons as required

        sStr = "'<br><hr class=new1><input class=""btn"" type=""button"" value=""Route"" onClick=""toggleRoute();""/>';"
        sJScript = sJScript & "document.getElementById(""side_bar"").innerHTML = side_bar_html + " & sStr & vbCrLf

        'Create the toggleRoute function
        sJScript = sJScript & "var routeToggleState = 0;" & vbCrLf
        sJScript = sJScript & "function toggleRoute() {" & vbCrLf
        sJScript = sJScript & "if (routeToggleState == 1) {" & vbCrLf
        sJScript = sJScript & "poly.setMap(null);" & vbCrLf
        sJScript = sJScript & "routeToggleState = 0;" & vbCrLf
        sJScript = sJScript & "} else {" & vbCrLf
        sJScript = sJScript & "poly.setMap(map);" & vbCrLf
        sJScript = sJScript & "routeToggleState = 1;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'Function to breakout the Street View window
        sJScript = sJScript & "function zoomSV(vLat, vLong) " & vbCrLf
        sJScript = sJScript & "{" & vbCrLf
        sJScript = sJScript & "varStr = 'Lat=' + vLat + '&Long=' + vLong" & vbCrLf
        sJScript = sJScript & "varURL = 'ZoomSV.aspx?' + varStr;" & vbCrLf
        sJScript = sJScript & "objWin = window.open(varURL, '', 'left=10,top=10,toolbar=false,status=false,directories=false,menubar=false,scrollbars=no,resizable=yes,copyhistory=false,width=825,height=525');" & vbCrLf
        sJScript = sJScript & "}  " & vbCrLf

        '****************************************************************************************
        'A function to create the marker and set up the event window for Bus Stop Alerts
        sJScript = sJScript & "function createConstructionMarker(point,html,desc) {" & vbCrLf
        sJScript = sJScript & "var image = new google.maps.MarkerImage('images/construction.png');" & vbCrLf
        sJScript = sJScript & "var marker = new google.maps.Marker({" & vbCrLf
        sJScript = sJScript & "position: point, " & vbCrLf
        sJScript = sJScript & "animation: google.maps.Animation.DROP, " & vbCrLf
        sJScript = sJScript & "icon: image, " & vbCrLf
        sJScript = sJScript & "map: map});" & vbCrLf
        sJScript = sJScript & "var infowindow = new google.maps.InfoWindow({content: html});" & vbCrLf
        sJScript = sJScript & "google.maps.event.addListener(marker, ""click"", function() {" & vbCrLf
        sJScript = sJScript & "infowindow.open(map,marker);" & vbCrLf
        sJScript = sJScript & "});" & vbCrLf
        'save the info we need to use later for the side_bar
        sJScript = sJScript & "gmarkers.push(marker);" & vbCrLf
        'add a line to the Detours Div
        sJScript = sJScript & "document.getElementById(""Detours"").innerHTML += '<a href=""javascript:myclick(' + (gmarkers.length-1) + ')"">' + desc + '<\/a><br>';" & vbCrLf
        sJScript = sJScript & "return marker;" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'This function picks up the click and opens the corresponding info window
        sJScript = sJScript & "function myclick(i) {" & vbCrLf
        sJScript = sJScript & "google.maps.event.trigger(gmarkers[i], ""click"");" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf

        'Look for Bus Stop Status info
        If Request.QueryString("Route") = "yes" Then
            sSQL = "SELECT * FROM qselBusStopStatusForBusLocator WHERE [RTE] = " & CInt(objDt.Rows(0).Item("Route")) & ""
            Dim sConn6 = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
            Dim oConn6 As New SqlConnection(sConn6)
            Dim oComm6 As New SqlCommand(sSQL, oConn6)
            oComm6.CommandType = CommandType.Text

            oConn6.Open()

            Dim dr6 As SqlDataReader

            dr6 = oComm6.ExecuteReader()
            Dim sStatus As String = ""
            Dim sStr1 As String = ""
            i = 0
            'Display return value
            Do While dr6.Read()

                If i = 0 Then sJScript = sJScript & "document.getElementById(""Detours"").innerHTML += ""<hr class=new1><br><div class=SideBar><u>Bus Stop Alert</u></div><br>""" & vbCrLf

                sStr1 = "<div class=red><u>Bus Stop Alert</u></div>"
                sStr1 = sStr1 & "<div><span><strong>Stop ID: </strong></span>" & dr6("BusStopID") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>Date Posted: </strong></span>" & dr6("CreatedDate") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>Start Date: </strong></span>" & dr6("StartDate") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>End Date: </strong></span>" & dr6("EndDate") & "</div>"
                sStr1 = sStr1 & "<div><span><strong>Date Last Checked: </strong></span>" & dr6("DateLastChecked") & "</div>"
                sStr1 = sStr1 & "<div><strong>St/X St: </strong>" & dr6("STREET") & "/" & dr6("CrossStreet") & "</div>"
                sStr1 = sStr1 & "<div><strong>Dir: </strong>" & dr6("Direction") & "</div>"

                sDesc = "Stop ID# " & dr6("BusStopID")

                'IIf(IsDBNull(dr6("Status")), 0, Trim(dr6("Status")))

                'Select Case dr6("Status")
                '    Case 1
                'sStatus = "Under Construction"
                '    Case 2
                'sStatus = "Stop Unavailable"
                '    Case 3
                'sStatus = "Temporary Stop"
                '    Case Else
                'sStatus = "Other"
                'End Select

                'sStr1 = sStr1 & "<div><strong>Status: </strong>" & sStatus & "</div>"
                sStr1 = sStr1 & "<div><strong>Notes: </strong>" & dr6("Description") & "</div><br>"

                '***
                sStr1 = sStr1 & "<a href=javascript:zoomSV(" & dr6("Lat") & "," & dr6("Long") & ")><span><strong class='red'>Street View</strong></span></a><br>"
                sURL = "http://maps.google.com/maps?q=" & dr6("Lat") & "+" & dr6("Long") & "&iwloc=A&hl=en&lci=transit&dirflg=r&z=16"
                sStr1 = sStr1 & "<a href=" & sURL & " target=_blank><span><strong class='red'>View in Google Maps</strong></span></a>"
                '***

                sJScript = sJScript & "var point = new google.maps.LatLng(" & dr6("Lat") & ", " & dr6("Long") & ");" & vbCrLf
                sJScript = sJScript & "var marker = createConstructionMarker(point, """ & sStr1 & """, """ & sDesc & """)" & vbCrLf
                sJScript = sJScript & "marker.setMap(map);" & vbCrLf
                i = i + 1
            Loop

            dr6.Close()
            oConn6.Close()
        End If
        '****************************************************************************************

        sJScript = sJScript & "</scr" & "ipt>"
        ClientScript.RegisterClientScriptBlock(GetType(MyBus), "NewWin", sJScript)

LoadJavaScriptGFI_Exit:
        Exit Sub

LoadJavaScriptGFI_Error:
        Dim sMsg As String = ""

        sMsg = "Error Number: " & Err.Number & vbCrLf & "Description: " & Err.Description & ""

        sMsg = HttpUtility.UrlEncode(sMsg)
        Response.Redirect("MessageDisplay.aspx?Msg=" & sMsg & "")

        Resume LoadJavaScriptGFI_Exit

    End Sub
End Class
