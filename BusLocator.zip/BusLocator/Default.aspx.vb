
Imports System.Data.SqlClient
Imports System.IO
Partial Class _Default
    Inherits System.Web.UI.Page

    Public Function ErrorMessage(sMessage As String) As String
        Dim sJScript As String

        ErrorMessage = ""
        Me.ModalErrorMsg.InnerHtml = sMessage

        sJScript = "<script type=""text/javascript"">" & vbCrLf
        sJScript = sJScript & "var modal = document.getElementById('ErrorModal');" & vbCrLf
        sJScript = sJScript & "var span = document.getElementsByClassName('Errorclose')[0];" & vbCrLf
        sJScript = sJScript & "modal.style.display = 'block';" & vbCrLf
        sJScript = sJScript & "span.onclick = function() {" & vbCrLf
        sJScript = sJScript & "modal.style.display = 'none';" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "window.onclick = function(event) {" & vbCrLf
        sJScript = sJScript & "if (event.target == modal) {" & vbCrLf
        sJScript = sJScript & "modal.style.display = 'none';" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "}" & vbCrLf
        sJScript = sJScript & "</scr" & "ipt>"
        ClientScript.RegisterClientScriptBlock(GetType(MyBus), "NewWin", sJScript)

    End Function

    Protected Sub cmdGo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdBusSearch.Click
        Dim sSQL As String = ""
        Dim sStr As String = ""
        Dim sCriteria As String = ""
        Dim strBusNumber As String = ""
        Dim strDriverID As String = ""

        Session.Clear()
        Session("BusSearch") = True

        Me.tMain.Enabled = False

        If Me.cboBus.Text <> "" Then
            sCriteria = sCriteria & "(BusNumber = '" & Me.cboBus.Text & "') AND "
        End If

        If Me.cboBlock.Text <> "" Then
            sCriteria = sCriteria & "(BLOCK = '" & Me.cboBlock.Text & "') AND "
        End If

        If Me.cboBadge.Text <> "" Then
            sCriteria = sCriteria & "(DRIVER_ID = '" & Me.cboBadge.Text & "') AND "
        End If

        If sCriteria = "" Then
            ErrorMessage("You must select some criteria.")
            Exit Sub
        Else
            sCriteria = Left(sCriteria, Len(sCriteria) - 5)
            'sSQL = "Select BusNumber, DRIVER_ID From OPENQUERY(STORBCAD, 'SELECT BusNumber, DRIVER_ID FROM ORBCADAPP.vwSearchCurrentLocation WHERE " & sCriteria & "')"
            sSQL = "Select BusNumber, DRIVER_ID From dbo.vwOrbCADVehicleDriver WHERE " & sCriteria & ""
        End If

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()
        oComm.CommandTimeout = 100

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        Do While dr.Read()
            strBusNumber = dr("BusNumber")
            strDriverID = dr("DRIVER_ID")
            Session("DriverID") = strDriverID
        Loop

        Dim sMsg As String = ""
        If strBusNumber = "" Then
            sMsg = "Location not currently available"
            sMsg = HttpUtility.UrlEncode(sMsg)
            Me.SpiceIframe1.SourceURL = "MessageDisplay.aspx?Msg=" & sMsg & ""
            Exit Sub
        End If

        Me.ViewDetails.Visible = False
        Me.hfPage.Value = "BusLocationDetails.aspx?DriverID=" & strDriverID & ""
        Me.SpiceIframe1.SourceURL = "BusTracker.aspx?BusNumber=" & strBusNumber & ""

        Exit Sub

        'Original code before GPS**********************************************************************************************************************

        'Dim sSQL As String = ""
        'Dim sStr As String = ""
        'Dim sCriteria As String = ""

        Session.Clear()
        Session("BusSearch") = True

        Me.tMain.Enabled = False
        Me.hfPage.Value = "BusLocationDetails.aspx"
        Me.AutoRefresh.Visible = True
        Me.ViewDetails.Visible = True

        If Me.cboBus.Text <> "" Then
            sCriteria = sCriteria & "(BusNumber = ''" & CStr(Me.cboBus.Text) & "'') AND "
        End If

        If Me.cboBlock.Text <> "" Then
            sCriteria = sCriteria & "(BLOCK = " & Me.cboBlock.Text & ") AND "
        End If

        If Me.cboBadge.Text <> "" Then
            sCriteria = sCriteria & "(BadgeNumber = ''" & Me.cboBadge.Text & "'') AND "
        End If

        If sCriteria = "" Then
            ErrorMessage("You must select some criteria.")
            Exit Sub
        Else
            sCriteria = Left(sCriteria, Len(sCriteria) - 5)
            sSQL = "Select * From OPENQUERY(STORBCAD, 'SELECT * FROM ITMSAPP.vwSearchCurrentLocation WHERE " & sCriteria & "')"

        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=Search"

    End Sub

    Private Sub LoadBadge(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        sSQL = "SELECT * FROM OPENQUERY(STORBCAD, 'Select USER_ID, USER_ID || '' - '' || FIRST_NAME || '' '' || LAST_NAME AS Operator FROM ITMSAPP.CAD_USER WHERE LENGTH(USER_ID) = 7 AND ROLE_IND IN(8, 15, 19) ORDER BY USER_ID')"
        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()
        oControl.DataSource = oReader
        oControl.DataTextField = "Operator"
        oControl.DataValueField = "User_ID"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()
        oConn.Dispose()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Private Sub LoadBlock(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        sSQL = "SELECT * FROM OPENQUERY(STORBCAD, 'SELECT ITMSAPP.BLOCK.BLOCK_ID AS Bus_Run FROM ITMSAPP.BLOCK WHERE NONSCHEDULE = 0 ORDER BY BLOCK_ID')"

        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Bus_Run"
        oControl.DataValueField = "Bus_Run"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()
        oConn.Dispose()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub

    Private Sub LoadBus(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        sSQL = "SELECT BusNumber AS Bus FROM qselBATS"

        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Bus"
        oControl.DataValueField = "Bus"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()

        'Reset the combobox
        oControl.Items.Insert(0, "")

    End Sub
    Private Sub LoadRoute(ByRef oControl As DropDownList)
        Dim sSQL As String
        Dim sConn As String

        'sSQL = "SELECT * FROM OPENQUERY(STORBCAD, 'SELECT ORBCADAPP.ROUTE.ROUTE_ID AS Route FROM ORBCADAPP.ROUTE WHERE PHY_FILENAME <> ''Special'' ORDER BY ROUTE_ID')"
        sSQL = "SELECT CONVERT(int, [Line]) AS Route FROM dbo.[List Of Lines] ORDER BY CONVERT(int, [Line])"

        sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)

        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim oReader As SqlDataReader
        oReader = oComm.ExecuteReader()

        oControl.DataSource = oReader
        oControl.DataTextField = "Route"
        oControl.DataValueField = "Route"
        oControl.DataBind()

        oReader.Close()
        oConn.Close()
        oConn.Dispose()

        'Reset the combobox
        oControl.Items.Insert(0, "0")

    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim sSQL As String = ""

        If Not IsPostBack Then
            Me.AutoRefresh.Visible = False
            Me.ViewDetails.Visible = False
            LoadBlock(cboBlock)
            LoadBadge(cboBadge)
            LoadBadge(cboAVLBadge)
            LoadRoute(cboRoute)
            LoadRoute(cboRteAnaRoute1)
            LoadRoute(cboRteAnaRoute2)
            LoadBadge(cboBadgeGFI)
            LoadRoute(cboRouteGFI)
            LoadBus(cboBusGFI)
            Me.tMain.Enabled = False
            Me.hfPage.Value = "BusLocationDetails.aspx"
            If Request.QueryString("SQLString") <> Nothing Then
                Me.txtAVLDate.Text = Request.QueryString("Date")
                Me.txtAVLStartTime.Text = Request.QueryString("StartTime")
                Me.txtAVLEndTime.Text = Request.QueryString("EndTime")
                Me.cboAVLBadge.SelectedIndex = cboAVLBadge.Items.IndexOf(cboAVLBadge.Items.FindByText(Request.QueryString("Badge")))
                Me.cboAVLBlock.Text = Request.QueryString("Block")
                Me.cboAVLBus.Text = Request.QueryString("BusNum")
                sSQL = HttpUtility.UrlEncode(Request.QueryString("SQLString"))
                Call cmdAVLSearch_Click(Nothing, EventArgs.Empty)
            End If
            If Request.QueryString("Mode") = "ShowGFI" Then
                Me.txtGFIDate.Text = Request.QueryString("Date")
                Me.cboRouteGFI.SelectedIndex = cboRouteGFI.Items.IndexOf(cboRouteGFI.Items.FindByText(Request.QueryString("Route")))
                Me.cboDirectionGFI.SelectedIndex = cboDirectionGFI.Items.IndexOf(cboDirectionGFI.Items.FindByValue(Request.QueryString("Direction")))
                Me.cboBusGFI.SelectedIndex = cboBusGFI.Items.IndexOf(cboBusGFI.Items.FindByText(Request.QueryString("BusNo")))
                Me.txtBlockGFI.Text = Request.QueryString("BusRun")
                Me.cboBadgeGFI.SelectedIndex = cboBadgeGFI.Items.IndexOf(cboBadgeGFI.Items.FindByText(Request.QueryString("Badge")))
                Me.txtStartTimeGFI.Text = Request.QueryString("Time")
                Me.cboTimeRange.SelectedIndex = cboTimeRange.Items.IndexOf(cboTimeRange.Items.FindByText(Request.QueryString("TimeRange")))
                sSQL = HttpUtility.UrlEncode(Request.QueryString("sSql"))
                Call cmdGFISearch_Click(Nothing, EventArgs.Empty)
            End If
            Call PageHitCount()
        End If

    End Sub
    Protected Sub PageHitCount()

        Dim iCount As Integer
        Dim sSQL As String = ""
        sSQL = "SELECT Value FROM dbo.tblSystem WHERE Name = 'BusLocatorPageHits'"

        Dim sConn = System.Configuration.ConfigurationManager.ConnectionStrings("TOPCARConnStr").ConnectionString
        Dim oConn As New SqlConnection(sConn)
        Dim oComm As New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        Dim dr As SqlDataReader

        dr = oComm.ExecuteReader()

        'Display return value
        Do While dr.Read()
            iCount = dr("Value")
        Loop

        oConn.Close()
        oComm = Nothing

        sSQL = ""
        sSQL = "UPDATE dbo.tblSystem SET Value = " & iCount + 1 & " WHERE Name = 'BusLocatorPageHits'"

        oConn = New SqlConnection(sConn)
        oComm = New SqlCommand(sSQL, oConn)
        oComm.CommandType = CommandType.Text

        oConn.Open()

        dr = oComm.ExecuteReader()

        dr.Close()
        oConn.Close()
        oComm = Nothing

    End Sub
    Protected Sub cmdRouteSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRouteSearch.Click

        Dim sCriteria As String = ""
        Dim sSQL As String = ""

        Session.Clear()
        Session("RouteSearch") = True
        Me.AutoRefresh.Visible = False
        Me.ViewDetails.Visible = True
        Me.tMain.Enabled = False
        Me.hfPage.Value = "BusDriverDetails.aspx"

        If Me.cboRoute.Text <> "" Then
            sCriteria = sCriteria & "(Route = " & cboRoute.Text & ")"
        End If

        If sCriteria = "" Then
            ErrorMessage("You must Select some criteria.")
            Exit Sub
        Else
            sSQL = "Select * FROM OPENQUERY(STORBCAD, 'SELECT * FROM ITMSAPP.vwSearchCurrentRoute WHERE " & sCriteria & " ORDER BY VehicleTime')"
        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=Route"

    End Sub

    Protected Sub cmdAVLSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAVLSearch.Click
        Dim sCriteria As String = ""
        Dim sSQL As String = ""
        Dim sDate As String = ""
        Dim sBlock As String = ""
        Dim sRoute As String = ""
        Dim dStartTime As DateTime
        Dim dEndTime As DateTime

        Session.Clear()
        Session("AVLSearch") = True
        Me.tMain.Enabled = False
        Me.hfPage.Value = "BusLocationDetails.aspx"
        Me.AutoRefresh.Visible = False
        Me.ViewDetails.Visible = False

        If Me.txtAVLDate.Text <> "" Then
            sDate = CDate(Me.txtAVLDate.Text).ToString("dd-MMM-yyyy")
        Else
            ErrorMessage("You must select a date.")
            Exit Sub
        End If

        If Me.cboAVLBus.Text <> "" Then
            sCriteria = sCriteria & "(BusNumber = ''" & CStr(Me.cboAVLBus.Text) & "'') AND "
        End If

        If Me.cboAVLBlock.Text <> "" Then
            sCriteria = sCriteria & "(Block = " & Me.cboAVLBlock.Text & ") AND "
            'sCriteria = sCriteria & "(Block = 18271) AND "
        End If

        If Me.cboAVLBadge.Text <> "" Then
            sCriteria = sCriteria & "(BadgeNumber = ''" & Me.cboAVLBadge.Text & "'') AND "
        End If

        If Me.txtAVLStartTime.Text <> "" And Me.txtAVLEndTime.Text <> "" Then
            dStartTime = CDate(Me.txtAVLStartTime.Text).ToLongTimeString
            dEndTime = CDate(Me.txtAVLEndTime.Text).ToLongTimeString
            sCriteria = sCriteria & "(VEHICLE_POSITION_DATE_TIME Between TO_DATE(''" & CDate(sDate & " " & dStartTime).ToString("dd-MMM-yyyy HH:mm:ss") & "'', ''dd-mon-yyyy hh24:mi:ss'') AND TO_DATE(''" & CDate(sDate & " " & dEndTime).ToString("dd-MMM-yyyy HH:mm:ss") & "'', ''dd-mon-yyyy hh24:mi:ss'')) AND "
        Else
            ErrorMessage("You must select an incident time.")
            Exit Sub
        End If

        If sCriteria = "" Then
            ErrorMessage("You must select some criteria.")
            Exit Sub
        Else
            sCriteria = Left(sCriteria, Len(sCriteria) - 5)
            If sDate < DateAdd(DateInterval.Day, -14, Date.Now) Then
                sSQL = "SELECT * FROM OPENQUERY(LTORBCAD, 'SELECT * FROM ITMSAPP.vwSearchHistoricalLocation WHERE " & sCriteria & " ORDER BY VEHICLE_POSITION_DATE_TIME')"
            Else
                sSQL = "SELECT * FROM OPENQUERY(STORBCAD, 'SELECT * FROM ITMSAPP.vwSearchHistoricalLocation WHERE " & sCriteria & " ORDER BY VEHICLE_POSITION_DATE_TIME')"
            End If
        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        If sDate < DateAdd(DateInterval.Day, -14, Date.Now) Then
            Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=AVL&DB=LT"
        Else
            Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=AVL&DB=ST"
        End If

    End Sub

    Protected Sub cmdPauseUpdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdPauseUpdate.Click

        If Me.tMain.Enabled = True Then
            Me.tMain.Enabled = False
            AutoRefresh.InnerHtml = "Auto Refresh"
        Else
            Me.tMain.Enabled = True
            AutoRefresh.InnerHtml = "Pause Refresh"
        End If

    End Sub

    Protected Sub cmdClearAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClearAll.Click

        Me.tMain.Enabled = False
        Me.txtAVLDate.Text = ""
        Me.txtAVLEndTime.Text = ""
        Me.txtAVLStartTime.Text = ""
        Me.cboAVLBadge.SelectedIndex = -1
        Me.cboAVLBlock.Text = ""
        Me.cboAVLBus.Text = ""
        Me.cboRoute.SelectedIndex = -1
        Me.cboBadge.SelectedIndex = -1
        Me.cboBlock.SelectedIndex = -1
        Me.cboBus.Text = ""
        Me.txtGFIDate.Text = ""
        Me.cboRouteGFI.SelectedIndex = -1
        Me.cboDirectionGFI.SelectedIndex = -1
        Me.cboBusGFI.SelectedIndex = -1
        Me.txtBlockGFI.Text = ""
        Me.cboBadgeGFI.SelectedIndex = -1
        Me.txtStartTimeGFI.Text = ""
        Me.cboBusNumer.Text = ""
        Session.RemoveAll()
        Me.AutoRefresh.Visible = False
        Me.ViewDetails.Visible = False
        Me.SpiceIframe1.SourceURL = "~/MyBus.aspx"

    End Sub

    Protected Sub cmdGFISearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdGFISearch.Click
        Dim sSQL As String = ""
        Dim sCriteria As String = ""
        Dim dStartTime As Date
        Dim dEndTime As Date
        Dim sStartTime As String
        Dim sEndTime As String
        Dim sBusNumber As String
        Dim sTransDate As String

        Session.Clear()
        Session("GFISearch") = True
        Me.AutoRefresh.Visible = False
        Me.ViewDetails.Visible = False

        If Me.txtGFIDate.Text <> "" Then
            sTransDate = CDate(Me.txtGFIDate.Text).ToString("yyyy-MM-dd")
            sCriteria = "(TRANSACTION_DATE = ''" & sTransDate & "'') AND "
        End If

        If Me.cboRouteGFI.SelectedValue <> "" Then
            sCriteria = sCriteria & "(ROUTE = " & Me.cboRouteGFI.SelectedValue & ") AND "
        End If

        If Me.cboDirectionGFI.SelectedValue <> "" Then
            sCriteria = sCriteria & "(Direction = ''" & Me.cboDirectionGFI.SelectedValue & "'') AND "
        End If

        If Me.cboBusGFI.SelectedValue <> "" Then
            sBusNumber = Me.cboBusGFI.SelectedValue.PadLeft(6, "0"c)
            sCriteria = sCriteria & "(Bus = ''" & sBusNumber & "'') AND "
        End If

        If Me.txtBlockGFI.Text <> "" Then
            sCriteria = sCriteria & "(BUS_RUN = " & Me.txtBlockGFI.Text & ") AND "
        End If

        If Me.cboBadgeGFI.SelectedValue <> "" Then
            sCriteria = sCriteria & "(BADGE = ''0" & Me.cboBadgeGFI.SelectedValue & "'') AND "
        End If

        If Me.txtStartTimeGFI.Text <> "" And Me.cboTimeRange.SelectedValue <> "" Then
            dStartTime = CDate(DateAdd("n", -(Me.cboTimeRange.SelectedValue), Me.txtStartTimeGFI.Text)).ToLongTimeString
            dEndTime = CDate(DateAdd("n", +(Me.cboTimeRange.SelectedValue), Me.txtStartTimeGFI.Text)).ToLongTimeString
            sStartTime = dStartTime.ToString("HH:mm:ss")
            sEndTime = dEndTime.ToString("HH:mm:ss")
            sCriteria = sCriteria & "(ARRIVE_TIME Between  ''" & sStartTime & "'' AND ''" & sEndTime & "'') AND "
        End If

        If sCriteria = "" Then
            MsgBox("You must select some criteria.", vbInformation)
        Else
            sCriteria = Left(sCriteria, Len(sCriteria) - 5)
            sSQL = "SELECT * FROM OPENQUERY(DWTEST, 'SELECT * FROM AVL_TARG.FACT_AVL_VW WHERE " & sCriteria & " ORDER BY ARRIVE_TIME')"
        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=yes&Mode=GFI"

    End Sub

    Private Sub cmdRouteAnalysis_Click(sender As Object, e As EventArgs) Handles cmdRouteAnalysis.Click
        Dim sCriteria As String = ""
        Dim sSQL As String = ""
        Dim sDate As String = ""
        Dim sBlock As String = ""
        Dim sRoute As String = ""
        Dim dStartTime As DateTime
        Dim dEndTime As DateTime

        Session.Clear()
        Session("RouteAnalysis") = True
        Me.AutoRefresh.Visible = False
        Me.ViewDetails.Visible = False

        If Me.txtRteAnaDate.Text <> "" Then
            sDate = CDate(Me.txtRteAnaDate.Text).ToString("dd-MMM-yyyy")
        Else
            ErrorMessage("You must select a date.")
            Exit Sub
        End If

        If Me.cboRteAnaRoute1.Text <> "" And Me.cboRteAnaRoute2.Text <> "" Then
            sCriteria = sCriteria & "((INCIDENT_LOG.CURRENT_ROUTE_ID = " & Me.cboRteAnaRoute1.Text & ") OR "

        ElseIf Me.cboRteAnaRoute1.Text <> "" And Me.cboRteAnaRoute2.Text = "" Then
            sCriteria = sCriteria & "(INCIDENT_LOG.CURRENT_ROUTE_ID = " & Me.cboRteAnaRoute1.Text & ") AND "
        Else
            ErrorMessage("You must select a Route.")
            Exit Sub
        End If

        If Me.cboRteAnaRoute2.Text <> "" Then
            sCriteria = sCriteria & "(INCIDENT_LOG.CURRENT_ROUTE_ID = " & Me.cboRteAnaRoute2.Text & ")) AND "
        End If

        If Me.txtRteAnaStartTime.Text <> "" And Me.txtRteAnaEndTime.Text <> "" Then
            dStartTime = CDate(Me.txtRteAnaStartTime.Text).ToLongTimeString
            dEndTime = CDate(Me.txtRteAnaEndTime.Text).ToLongTimeString
            sCriteria = sCriteria & "(VEHICLE_POSITION_LOG.VEHICLE_POSITION_DATE_TIME Between TO_DATE(''" & CDate(sDate & " " & dStartTime).ToString("dd-MMM-yyyy HH:mm:ss") & "'', ''dd-mon-yyyy hh24:mi:ss'') AND TO_DATE(''" & CDate(sDate & " " & dEndTime).ToString("dd-MMM-yyyy HH:mm:ss") & "'', ''dd-mon-yyyy hh24:mi:ss'')) "
        Else
            ErrorMessage("You must select an incident time.")
            Exit Sub
        End If

        If sCriteria = "" Then
            ErrorMessage("You must select some criteria.")
            Exit Sub
        End If

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "AVL.aspx?sCriteria=" & sCriteria & "&Inter=" & Me.txtIntersection.Text & "&Start=" & Me.txtRteAnaDate.Text & " " & Me.txtRteAnaStartTime.Text & "&End=" & Me.txtRteAnaDate.Text & " " & Me.txtRteAnaEndTime.Text & "&Speed=" & Me.txtSpeed.Text

    End Sub
    Protected Sub cmdBusLocation_Click(sender As Object, e As EventArgs) Handles cmdBusLocation.Click
        Dim sCriteria As String = ""
        Dim sSQL As String = ""

        Session.Clear()
        Me.tMain.Enabled = False
        Me.hfPage.Value = "BusDriverDetails.aspx"

        If Me.cboBusNumer.Text <> "" Then
            sCriteria = sCriteria & "(VEHICLE_ID = " & cboBusNumer.Text & ")"
        End If

        sSQL = "Select * FROM OPENQUERY(STORBCAD, "
        sSQL = sSQL & "'SELECT VEHICLE_ID AS BusNumber, "
        sSQL = sSQL & "VEHICLE_POSITION_DATE_TIME, "
        sSQL = sSQL & "LOC_X AS Lon, "
        sSQL = sSQL & "LOC_Y AS Lat, "
        sSQL = sSQL & "TO_CHAR(VEHICLE_POSITION_DATE_TIME,''MM/DD/YYYY'') AS VehicleDate, "
        sSQL = sSQL & "TO_CHAR(VEHICLE_POSITION_DATE_TIME,''HH24:MI:SS'') AS VehicleTime "
        sSQL = sSQL & "FROM ("
        sSQL = sSQL & "SELECT VEHICLE_ID, "
        sSQL = sSQL & "VEHICLE_POSITION_DATE_TIME, "
        sSQL = sSQL & "LOC_X, "
        sSQL = sSQL & "LOC_Y, "
        sSQL = sSQL & "ROW_NUMBER() OVER(ORDER BY VEHICLE_POSITION_DATE_TIME desc) RN "
        sSQL = sSQL & "FROM ITMSAPP.VEHICLE_POSITION_LOG "
        sSQL = sSQL & "WHERE " & sCriteria & ""
        sSQL = sSQL & ") "
        sSQL = sSQL & "WHERE RN = 1')"

        sSQL = HttpUtility.UrlEncode(sSQL)
        Me.SpiceIframe1.SourceURL = "MyBus.aspx?sSql=" & sSQL & "&Route=no&Mode=Maintenance"

    End Sub
End Class

